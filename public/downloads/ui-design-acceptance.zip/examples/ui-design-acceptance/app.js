const $=s=>document.querySelector(s); const version=document.body.dataset.version;
const key=`ui-acceptance-${version}`; let saved={};let storageOK=true;
try{saved=JSON.parse(localStorage.getItem(key)||'{}');}catch{storageOK=false;}
let ideas=[];let opener=null;const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const status=i=>saved[i.id]||i.status;
function render(){
 const term=$('#search').value.trim().toLowerCase();const filter=$('#filter').value;
 const rows=ideas.filter(i=>(filter==='all'||status(i)===filter)&&`${i.title} ${i.hypothesis}`.toLowerCase().includes(term));
 $('#count').textContent=`显示 ${rows.length} / ${ideas.length} 条`;
 if(!ideas.length){$('#list').innerHTML='<div class="empty"><h3>还没有假设</h3><p>当前数据集为空。此演示不提供新建功能，可返回示例查看完整流程。</p><a href="'+version+'.html">返回合成示例</a></div>';return;}
 if(!rows.length){$('#list').innerHTML='<div class="empty"><h3>没有匹配的假设</h3><p>试试其他关键词，或清除状态筛选。</p><button id="clear">清除筛选</button></div>';$('#clear').onclick=()=>{$('#search').value='';$('#filter').value='all';render();$('#search').focus();};return;}
 $('#list').innerHTML=rows.map(i=>`<article class="idea" data-status="${status(i)}"><div class="meta"><span class="id">${i.id}</span><span class="status">${status(i)==='running'?'验证中':'待验证'}</span><span>${i.evidence.length} 条证据</span></div><h3>${escapeHTML(i.title)}</h3><p class="hypothesis">${escapeHTML(i.hypothesis)}</p><p class="gap"><strong>证据缺口</strong><br>${escapeHTML(i.gap)}</p><button class="detail" data-id="${i.id}">查看证据与下一步</button></article>`).join('');
 document.querySelectorAll('.detail').forEach(b=>b.onclick=()=>{opener=b;showDetail(ideas.find(i=>i.id===b.dataset.id));});
}
function showDetail(i){
 $('#detail-body').innerHTML=`<div class="meta">${i.id} / 合成假设</div><h2 id="dialog-title" tabindex="-1">${escapeHTML(i.title)}</h2><p>${escapeHTML(i.hypothesis)}</p><h3>证据记录</h3>${i.evidence.length?'<ol>'+i.evidence.map(e=>`<li><strong>${escapeHTML(e.title)}</strong><br><span class="status">${escapeHTML(e.kind)}</span><p>${escapeHTML(e.text)}</p></li>`).join('')+'</ol>':'<p>暂无证据。先记录观察，不将缺失当作否定。</p>'}<h3>下一次验证</h3><p>${escapeHTML(i.next)}</p><button class="primary" id="launch" ${status(i)==='running'?'disabled':''}>${status(i)==='running'?'验证进行中':'发起验证'}</button><p id="launch-result" role="status">本操作仅更新本地状态，不会发送邀请或启动远端任务。</p>`;
 $('#launch').onclick=()=>{saved[i.id]='running';try{localStorage.setItem(key,JSON.stringify(saved));}catch{storageOK=false;}$('#launch').disabled=true;$('#launch').textContent='验证进行中';$('#launch-result').textContent=storageOK?'验证已发起，仅保存于当前浏览器':'验证已发起，但无法持久保存；刷新后可能丢失';render();opener=document.querySelector(`[data-id="${i.id}"]`);};
 $('dialog').showModal();
 $('#dialog-title').focus({preventScroll:true});$('dialog').scrollTop=0;
}
$('#close').onclick=()=>$('dialog').close();$('dialog').addEventListener('close',()=>{if(opener?.isConnected)opener.focus();else $('#search').focus();});
$('#search').oninput=render;$('#filter').onchange=render;
async function load(scenario){
 $('#list').innerHTML='';$('#notice').textContent='正在读取假设…';
 try{const response=await fetch('/api/ideas'+(scenario?'?scenario='+encodeURIComponent(scenario):''));if(!response.ok)throw Error('HTTP '+response.status);ideas=await response.json();$('#notice').textContent=storageOK?'证据全部为合成内容；状态按浏览器分别保存。':'本地存储不可用；状态不会持久保存。';render();}
 catch{$('#notice').textContent='';$('#count').textContent='读取失败';$('#list').innerHTML='<div class="error" role="alert"><h3>假设加载失败</h3><p>未能读取数据，没有把失败当成空列表。重试将恢复演示数据。</p><button id="retry">重试加载</button></div>';$('#retry').onclick=()=>load('');}
}
load(new URLSearchParams(location.search).get('scenario'));
