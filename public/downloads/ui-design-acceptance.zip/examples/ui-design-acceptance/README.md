# 试证：UI 设计分层验收教学案例

两版真实可运行界面，不是受控生成实验。全部业务数据为合成，发起验证仅写入浏览器localStorage。没有外部AI、账号、数据库、邀请或真实用户数据。

## 运行

需要 Node.js（实测22.19.0）、npm、已安装的Chrome。运行页面本身无需依赖或网络：

```sh
cd examples/ui-design-acceptance
node server.mjs
```

若直接进入本地交付目录，则使用其绝对路径。打开：
- http://127.0.0.1:4173/a.html 设计提示版
- http://127.0.0.1:4173/b.html 分层验收版

服务只监听127.0.0.1。`PORT=4174 node server.mjs` 可改端口。使用Ctrl-C停止。

## 自动浏览器检查

服务保持运行，另一终端在同一目录执行：

```sh
npm ci --ignore-scripts
npm test
```

测试依赖从npm下载，需要网络；页面和数据不请求外网。Playwright默认使用本机Chrome，不自动下载浏览器。没有Chrome可自行准备兼容Chromium并设置 `CHROME_PATH=/path/to/chromium npm test`；此备用路径没有跨平台验证。改端口时使用 `BASE_URL=http://127.0.0.1:4174 npm test`。

输出：`evidence/browser-results.json` 和 `assets/*.png`。测试会覆盖同名截图；要保留交付证据，可设置 `EVIDENCE_DIR=./test-output SHOTS_DIR=./test-output/shots npm test`。测试在隔离浏览器上下文运行，不改变你日常浏览器中的状态。

## 手动检查

两版都支持 `?scenario=long`、`?scenario=empty`、`?scenario=error`、`?scenario=slow`。error由服务端真实返回503；“重试加载”恢复标准合成数据。长数据仅用于压力测试，不是新增真实证据。

筛选“验证中”应先显示H-02；搜索不存在关键词应显示无结果；清除后恢复列表。打开H-01，查看支持与反对证据，再发起验证，关闭并刷新，状态保持验证中。每版使用不同localStorage key，A的动作不改变B。需要重置可用浏览器开发工具只清除本站点的 `ui-acceptance-a` 和 `ui-acceptance-b`，不要清理其他站点。

## 文件地图

- `brief.md`：固定需求、首屏草图、设计token和取舍。
- `prompts/generation.md`：两版实际输入、生成方式与比较局限。
- `a.html/a.css`、`b.html/b.css`：独立布局与样式。
- `app.js/base.css/data.json/server.mjs`：共同业务、基础样式、合成fixture和本地HTTP服务。
- `tests/browser.mjs`：实际浏览器交互、响应式、状态和截图检查。
- `review-checklist.md`：分层清单及独立复核入口。
- `acceptance-report.md`：实际结果及未测范围。
- `evidence/commands.md`：命令、版本、轮次、人工介入与成本边界。
- `evidence/before-fix/`：修复前视觉证据；assets/contact-*.png为初轮联系表，不能当最终详情图。
- `assets/a-*.png`、`assets/b-*.png`：最终自动化截图，除contact以外。
- `evidence/visual-review.md`：视觉工具自查摘要与定位。
- `research/`：固定commit源码快照、来源账本与核验说明（MIT许可证随附）。未调用Hallmark。

ZIP保留 `drafts/` 和 `examples/` 相对结构，文章图片可直接解析。发布前再映射媒体地址与下载地址；本交付没有发布。草稿不设发布日期；目标站点schema允许日期缺省。

## 完成边界

实测22/22检查组通过，并用视觉工具读取真实截图。没有独立评审、真实用户研究、完整无障碍合规验证、跨浏览器测试或真实后端集成。阅读检查不应被包装成这些结论。
