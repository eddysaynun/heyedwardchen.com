"""Validate prose/references/media; pack, extract, install, serve and test ZIP.
Run from any directory: python3 examples/ui-design-acceptance/tests/verify_delivery.py
All transient files are placed under the Hermes scratch directory, never /tmp.
"""
import hashlib,json,os,re,shutil,subprocess,time,urllib.request,uuid,zipfile
from pathlib import Path
example=Path(__file__).resolve().parents[1]
base=example.parents[1]
draft=base/'drafts/ui-design-acceptance.md'
articles=base/'articles';articles.mkdir(exist_ok=True)
text=draft.read_text()
prose=text.split('## 一、',1)[1].split('## 参考资料',1)[0]
prose=re.sub(r'```.*?```','',prose,flags=re.S)
prose=re.sub(r'!\[.*?\]\(.*?\)','',prose)
count=len(re.findall(r'[\u4e00-\u9fff]',prose));assert 4500<=count<=6500,count
assert len(re.findall(r'^## [一二三四五六七]、',text,re.M))==7
assert text.count('```')%2==0
for name in ['title','description','tags','draft','pinned']:assert re.search('^'+name+':',text,re.M)
media=re.findall(r'!\[.*?\]\((.*?)\)',text)
assert all((draft.parent/p).is_file() for p in media)
ledger=json.loads((example/'research/ledger.json').read_text())
# Ledger's list is authoritative, preserve ids and URL order.
entries=ledger.get('sources',ledger.get('entries',[]))
if isinstance(entries,dict):entries=list(entries.values())
urls=[e['url'] for e in entries]
refs=re.findall(r'^\d+\. \[.*?\]\((.*?)\)',text,re.M)
assert refs==urls,(refs,urls)
assert set(re.findall(r'\[(\d+)\]',text))=={'1','2','3','4'}
zip_path=articles/'ui-design-acceptance.zip'
files=[draft]+sorted(p for p in example.rglob('*') if p.is_file() and 'node_modules' not in p.parts and p.name!='.DS_Store' and '__pycache__' not in p.parts)
manifest={str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(base))
 z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
scratch=Path('/Users/edward/.hermes/cache/scratch')/('ui-delivery-'+uuid.uuid4().hex[:8]);scratch.mkdir(parents=True)
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
 assert set(z.namelist())==set(manifest)|{'MANIFEST.json'}
 z.extractall(scratch)
for name,digest in manifest.items():assert hashlib.sha256((scratch/name).read_bytes()).hexdigest()==digest
project=scratch/'examples/ui-design-acceptance'
verification=articles/'ui-design-acceptance-verification';verification.mkdir(exist_ok=True)
# The generic citation checker expects an English Sources block, not the site's Chinese ordered list.
# URL order above is already validated against the actual publishable references.
source_tool=Path.home()/'.hermes/skills/research/grounded-citations/scripts/sources.py'
if source_tool.exists():
 import sys
 command=[sys.executable,str(source_tool),'--ledger',str(example/'research/ledger.json')]
 rendered=subprocess.run(command+['render'],capture_output=True,text=True,check=True).stdout
 canonical=scratch/'citation-check.md';canonical.write_text(text.split('## 参考资料')[0]+rendered)
 checked=subprocess.run(command+['verify',str(canonical),'--evidence'],capture_output=True,text=True)
 (verification/'citation-verify.log').write_text(checked.stdout+checked.stderr)
 assert checked.returncode==0,checked.stdout+checked.stderr
def run(command,name,env=None):
 result=subprocess.run(command,cwd=project,env=env,capture_output=True,text=True,timeout=150)
 (verification/name).write_text(result.stdout+result.stderr)
 assert result.returncode==0,(command,result.stdout,result.stderr)
 return result.stdout
run(['npm','ci','--ignore-scripts'],'npm-ci.log')
env={**os.environ,'PORT':'4174'}
log=(verification/'server.log').open('w')
server=subprocess.Popen(['node','server.mjs'],cwd=project,env=env,stdout=log,stderr=log)
try:
 for _ in range(40):
  if server.poll() is not None:raise RuntimeError('extracted server exited')
  try:
   with urllib.request.urlopen('http://127.0.0.1:4174/b.html',timeout=1) as response:assert '下一步' in response.read().decode()
   break
  except OSError:time.sleep(.15)
 else:raise RuntimeError('server did not become ready')
 env={**os.environ,'BASE_URL':'http://127.0.0.1:4174','EVIDENCE_DIR':str(verification),'SHOTS_DIR':str(scratch/'verified-shots')}
 output=run(['npm','test'],'npm-test.log',env)
finally:
 server.terminate();server.wait(timeout=10);log.close()
results=json.loads((verification/'browser-results.json').read_text())['results']
assert len(results)==22 and all(r['pass'] for r in results)
report={'archive':str(zip_path),'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'archiveBytes':zip_path.stat().st_size,'manifestFileCount':len(manifest),'chineseProseCharacters':count,'mediaReferences':media,'extractedAt':str(scratch),'integrityAndSourceEquality':True,'npmCi':True,'browserChecksPassed':len(results),'browserChecksTotal':len(results),'independentReview':'pending','verificationEvidence':str(verification)}
(articles/'ui-design-acceptance-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2));print(output)
