// Reproduce native dialog autofocus without altering delivered application files.
import {chromium} from 'playwright';
import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const browser=await chromium.launch({channel:'chrome',headless:true});
const page=await browser.newPage({viewport:{width:375,height:812}});
try{
 await page.goto('http://127.0.0.1:4173/b.html?scenario=long');
 await page.locator('.detail').first().click();
 const fixed=await page.locator('dialog').evaluate(e=>({scrollTop:e.scrollTop,focus:document.activeElement.id}));
 await page.keyboard.press('Escape');
 const native=await page.evaluate(()=>{const title=document.querySelector('#dialog-title');title.removeAttribute('tabindex');const dialog=document.querySelector('dialog');dialog.showModal();return {scrollTop:dialog.scrollTop,focus:document.activeElement.id};});
 assert.equal(fixed.scrollTop,0);assert.equal(fixed.focus,'dialog-title');assert.ok(native.scrollTop>0);assert.equal(native.focus,'launch');
 const response=await page.request.get('http://127.0.0.1:4173/api/ideas?scenario=error');assert.equal(response.status(),503);
 const result={fixed,nativeWithoutTitleFocus:native,injectedHttpStatus:response.status(),method:'Isolated page DOM only: remove title tabindex and call native showModal without app focus correction.'};
 writeFileSync('evidence/dialog-diagnosis.json',JSON.stringify(result,null,2));console.log(result);
}finally{await browser.close();}
