# 真实验收报告

日期：2026-10-28；同作者教学对照，非受控实验。独立评审待主代理。
环境：Darwin arm64 27.0.0；Node v22.19.0；npm 11.12.1；Playwright 1.56.1；Google Chrome 156.0.8078.48。

## 功能结果
最终 `npm test`：22/22检查组通过，A/B各11组；组内含多条断言，不是22个用户或22次独立生成。结果证据：evidence/browser-results.json、browser-test.log。
检查组：load-and-desktop、filter-and-empty、detail-evidence、launch-and-persist、keyboard-focus、mobile-and-long-content、empty-dataset、http-failure-and-retry、loading、keyboard-dialog-and-responsive、no-page-errors。
1280×800正常首屏A首个动作顶端y=992.703125、高48.390625，B顶端y=612.4375、高48.390625。A在首屏外，B在首屏内；这是该视口和本机字体的几何观察，不是效率或审美分。
两版过滤、详情、发起与刷新、错误恢复都通过。没有为了制造胜负故意破坏A。

## 视觉自查与修复
调用 vision_analyze 读取 b-desktop.png、contact-desktop.png、contact-states.png，再读取原尺寸 a-mobile-long.png、b-mobile-long.png、修复后的 b-mobile-detail.png。联系表只作总览，不代替长页原图。视觉工具返回的描述由作者核对，不把其所有猜测当事实。
初轮脚本20/20通过，却发现长详情打开时已经滚到靠近底部：原生dialog自动聚焦第一个可交互按钮，长内容把按钮推远。修复为标题tabindex=-1、showModal后标题focus preventScroll、scrollTop=0；两版共享修复，不只优化B。补充初始焦点/scrollTop断言和移动键盘用例，最终22/22。
修复前图和结果保存在evidence/before-fix/。这是一次共享修复批次，没有重新生成多版挑最好看的一版。
最终原图确认：375px标题开头可见，长正文换行，无明显横向裁切，卡片/条目与按钮没有重叠。按钮在长页下方，脚本真实滚动点击关闭；不称所有操作在首屏可见。
保留非阻断意见：B移动副标题孤尾短行；跳过链接焦点态短暂遮盖页头；长内容需要滚动。

## 覆盖边界
真实浏览器点击、键盘和HTTP响应，不是静态mock截图；但业务数据是合成fixture，失败是服务端主动返回503，发起仅localStorage，无远端AI/数据库/邀请。未做真实用户研究、性能基准、读屏、完整对比度审计、Safari/Firefox或真实手机测试。不声称WCAG合规。
未安装、调用或跑Hallmark验收；只读官方固定commit源码，自建Playwright测试借鉴分层验收思路。
ZIP解压复测结果单独记录在articles/ui-design-acceptance-verification.json和同目录verification/中，不放进被校验ZIP以避免自引用哈希；归档验证只证明交付代码可运行，不替代视觉判断。
