# Hallmark 核验边界

仓库：https://github.com/Nutlope/hallmark
固定commit：6033bab2a8051b5454552d2e8e6cb8f27c483a42
取得方式：git clone --depth 1 后 rev-parse；只读研究。README及具体实现已读，原始文件快照与MIT LICENSE位于本目录。

- README：三层gate，hero-first，真实浏览器，新上下文评审，改版before/kept，Node/浏览器依赖。
- SKILL.md：第129–150行规定先首屏再页面与扫描；这些是给宿主代理的工作流指令，不是当前会话已经执行了它们的证据。
- sloplint.mjs：参数解析；4141–4166行render分支动态import sloplint-render.mjs，再调用renderCheck；异常保留renderNotRun。没有render或不可运行不应解释为浏览器已检查。
- sloplint-render.mjs：71–114行查找Puppeteer/Chrome并launch；149起检查WIDTHS，170起增加1440/1920截图与空间检查；193起真实Tab；231起归并pageerror。WIDTHS常量7种，另外1440是第8种不同宽度，不把常量长度误解成README不一致。

本文没有运行Hallmark工具，也没有安装Hallmark Skill、执行其theme/sloplint或独立评审；只是自建界面与Playwright测试借鉴三层验收。克隆源码不等于完成工具工作流。

本会话web_extract尝试读取固定README失败，提示所选后端仅搜索；不存在伪造在线提取结果。固定源码的引用由ledger.json登记，quote均校验在文件内。
