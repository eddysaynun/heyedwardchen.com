import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
const root=process.cwd(); const port=Number(process.env.PORT||4173);
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png'};
const files=new Set(['a.html','b.html','app.js','base.css','a.css','b.css','data.json']);
http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(url.pathname==='/api/ideas'){
  if(url.searchParams.get('scenario')==='error'){res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Injected fixture failure'}));return;}
  if(url.searchParams.get('scenario')==='slow')await new Promise(r=>setTimeout(r,1200));
  const data=JSON.parse(await readFile(resolve(root,'data.json'),'utf8'));
  if(url.searchParams.get('scenario')==='long'){data[0].title+='：'+ '同时保留原文出处、责任人与尚待确认的条件'.repeat(5);data[0].hypothesis+=' 合成的长内容用于检验换行，不应挤掉操作入口。'.repeat(12);}
  res.writeHead(200,{'Content-Type':types['.json'],'Cache-Control':'no-store'});res.end(JSON.stringify(url.searchParams.get('scenario')==='empty'?[]:data));return;
 }
 const name=url.pathname==='/'?'b.html':url.pathname.slice(1);
 if(!files.has(name)){res.writeHead(404);res.end('Not found');return;}
 try{const body=await readFile(resolve(root,name));res.writeHead(200,{'Content-Type':types[extname(name)]||'text/plain','Cache-Control':'no-store'});res.end(body);}catch{res.writeHead(404);res.end('Not found');}
}).listen(port,'127.0.0.1',()=>console.log(`Local synthetic demo: http://127.0.0.1:${port}/b.html`));
