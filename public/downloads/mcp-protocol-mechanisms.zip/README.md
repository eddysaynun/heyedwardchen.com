# 理解 MCP：协议架构、交互语义与互操作边界

未发布的完整文章与静态验证材料。正文采用已确认八节顺序，并含摘要、版本范围和34项有序参考资料。中文正文统计规则与结果见验证报告。

## 阅读

- `drafts/mcp-protocol-mechanisms.md`：正式完整稿，与交付目录中的稿件逐字节一致。
- `drafts/mcp-protocol-mechanisms.html`：可直接用浏览器打开的离线正文预览。
- `research/mcp-protocol-mechanisms/figures/`：架构、能力关系、MRTR时序三图，各含 PNG 和 SVG。Markdown 与 HTML 使用同一相对路径；请保留整个目录结构。
- `research/mcp-protocol-mechanisms/METHODOLOGY.md`：阅读范围、规范冲突、例子解释及未验证范围。笔记中的来源编号对应正文参考资料。
- `sources-final.json`、`ledger.json`、`versions.json`：固定来源、原文哈希、证据锚点、阅读范围和环境版本。完整原文路径是原研究目录路径，不表示包内附带全部第三方原文。

## 运行验证

在本包解压后的根目录执行（需要 Python 3.10+ 和已可用的 `jsonschema`）：

```sh
python research/mcp-protocol-mechanisms/verify.py --root .
```

脚本不联网、不启动 MCP 进程、不读写凭据。包括官方 schema 的六项对象检查、两个正文 JSON 块一致性、工具输入输出、MRTR 关联和能力、示意 HTTP 镜像头、12 个反例，以及图片、引文、HTML 和 MANIFEST 完整性检查。它是针对文章与示例的自制检查，不是完整官方 MCP 认证。

请不要把 `--output` 指向解压包内部再运行完整性检查；新增文件会使 MANIFEST 的严格成员集合检查失败。需要保存输出时，将文件放在包外。

`examples/` 的五条消息、一份工具描述和一份 HTTP 绑定均为教学数据。`requestState` 字符串是占位符，不是安全令牌；例子不执行报告分析、不实现授权或加密。

## 其他材料

- `static-verification.json`：打包前的静态验证结果；其 archive_integrity 为 null 是有意的。
- `visual-review.json`：三张 PNG 的实际两轮视觉审查结论及最终哈希。
- `browser-review.json`：本地离线 HTML 浏览器 DOM 检查。
- `normative-review.json`：逐项原文核查结果，不冒充运行测试。
- `MANIFEST.sha256.json`：除其自身之外所有 ZIP 文件成员的 SHA-256。它不能自证来源；整个 ZIP 的最终 SHA-256 在包外最终验证报告中。

最终独立解压报告单独交付为 `articles/mcp-protocol-mechanisms-verification.json`，不递归塞回 ZIP，避免哈希循环。最终报告核对 ZIP 成员集合与哈希、解压稿件和原稿一致性，并从新解压目录再次运行 `verify.py`。

## 再生成的限制

`draw_figures.py` 需要 Pillow 与合适的中文字体，当前使用 macOS STHeiti Light；字体不随包分发。PNG 可直接阅读，SVG 可编辑但会使用系统字体替代。

`render.mjs ROOT SITE_ROOT` 只读已有站点的 unified/remark/rehype 依赖；它不执行站点构建或同步命令。缺少对应依赖时，可直接读随包 HTML，不必安装 MCP 或修改站点。`build_bundle.py` 用于原输出根重新构建与校验交付包，并要求指定的 scratch 目录存在；通常读者只需执行 `verify.py`。

## 许可与范围

原创稿、图、示例和检查代码没有复制上游长篇正文。包内保留一份固定官方 `schema.json` 作为离线验证输入，内容未修改，附原仓库 LICENSE 与来源哈希；上游许可正在 MIT/Apache-2.0 过渡，遵循附带说明，不把它简化为单一许可。其他完整规范、RFC、OpenAPI 或平台文档均不在此包中。

没有验证真实 MCP 互操作、断连竞态、OAuth 流程、状态签名/反重放、业务幂等性或完整扩展实现；没有发布、推送 Git、修改站点、Obsidian 或 Hermes 配置。
