"""Original explanatory figures; Pillow PNG + editable SVG, no renderer plugin."""
from pathlib import Path
import math, html, json
from PIL import Image, ImageDraw, ImageFont
OUT = Path(__file__).parent / 'figures'
FONT = '/System/Library/Fonts/STHeiti Light.ttc'
INK, MUTED, BLUE, TEAL = '#162b42', '#526579', '#326eaa', '#16796d'
class Canvas:
    def __init__(self, height):
        self.w,self.h=1500,height
        self.im=Image.new('RGB',(self.w,self.h),'#f7f9fc'); self.d=ImageDraw.Draw(self.im)
        self.svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="{height}" viewBox="0 0 1500 {height}"><rect width="1500" height="{height}" fill="#f7f9fc"/>']
        self.text_bounds=[]
    def text(self,x,y,t,size=25,color=INK,center=False):
        font=ImageFont.truetype(FONT,size); width=self.d.textlength(t,font=font)
        if center: x-=width/2
        assert x>=0 and x+width<=self.w and y>=0 and y+size+8<=self.h, t
        self.d.text((x,y),t,font=font,fill=color,anchor='lt')
        self.svg.append(f'<text x="{x:.2f}" y="{y+size}" font-size="{size}" font-family="Heiti SC, Noto Sans CJK SC, sans-serif" fill="{color}">{html.escape(t)}</text>')
        self.text_bounds.append([x,y,width,size,t])
    def box(self,x,y,w,h,title,lines=(),fill='#ffffff',stroke='#c5d4e4'):
        self.d.rounded_rectangle((x,y,x+w,y+h),radius=15,fill=fill,outline=stroke,width=2)
        self.svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="15" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')
        self.text(x+20,y+20,title,27)
        for i,t in enumerate(lines): self.text(x+20,y+66+37*i,t,23,MUTED)
    def line(self,x1,y1,x2,y2,color=BLUE,arrow=True,both=False,dash=False):
        self.d.line((x1,y1,x2,y2),fill=color,width=3)
        self.svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="3"'+(' stroke-dasharray="7 7"' if dash else '')+'/>')
        def head(x,y,angle):
            pts=[(x,y),(x-14*math.cos(angle-0.42),y-14*math.sin(angle-0.42)),(x-14*math.cos(angle+0.42),y-14*math.sin(angle+0.42))]
            self.d.polygon(pts,fill=color); self.svg.append('<polygon points="'+' '.join(f'{a:.1f},{b:.1f}' for a,b in pts)+f'" fill="{color}"/>')
        a=math.atan2(y2-y1,x2-x1)
        if arrow: head(x2,y2,a)
        if both: head(x1,y1,a+math.pi)
    def title(self,n,t,sub):
        self.text(55,35,f'{n}  {t}',36); self.text(55,90,sub,23,MUTED)
    def save(self,name):
        OUT.mkdir(exist_ok=True); self.im.save(OUT/(name+'.png'))
        (OUT/(name+'.svg')).write_text('\n'.join(self.svg)+ '</svg>')
        return {'name':name,'size':[self.w,self.h],'text_count':len(self.text_bounds),'bounds_checked':True}

def main():
    checks=[]
    c=Canvas(800); c.title('01','参与者与控制边界','MCP 2026-07-28 · 概念架构；连线表示信息方向，不表示共享会话')
    c.box(340,140,580,530,'Host：协调、隔离与同意',fill='#eaf1fa')
    c.box(60,205,210,105,'用户',['提出任务目标'])
    c.box(60,435,210,145,'模型',['提出调用建议','接收选定上下文'])
    c.box(370,210,240,410,'宿主策略',['上下文选择','权限与用户确认','跨服务编排','结果解释'])
    c.box(670,240,210,145,'Client A',['逐请求元数据','消息关联'])
    c.box(670,450,210,145,'Client B',['逐请求元数据','消息关联'])
    c.box(1100,240,330,125,'Server A：文档',['资源读取 / 报告正文'])
    c.box(1100,450,330,125,'Server B：统计',['工具执行 / 分析结果'])
    c.line(270,255,370,255); c.line(270,495,370,495,both=True)
    c.line(610,300,670,300,both=True); c.line(610,510,670,510,both=True)
    c.line(880,300,1100,300,both=True); c.text(990,257,'MCP 消息',22,center=True)
    c.line(880,510,1100,510,both=True); c.text(990,467,'MCP 消息',22,center=True)
    c.text(55,710,'模型交互 ≠ MCP 连接；服务端只接收本次操作所需信息。',25)
    c.text(55,752,'架构依据：[2][4]。安全边界由实现落实，不因连通而自动成立。',21,MUTED)
    checks.append(c.save('architecture'))
    c=Canvas(980); c.title('02','能力关系与控制位置','MCP 2026-07-28 · 三类核心对象可组合，但不互相替代')
    c.box(55,165,430,255,'Resources · 内容',['标识：URI','发现 / 读取：list / read','应用组织上下文','例：年度报告正文'])
    c.box(535,165,430,255,'Tools · 动作',['标识：名称 + 参数契约','发现 / 执行：list / call','模型建议，宿主审批','例：报告指标分析'])
    c.box(1015,165,430,255,'Prompts · 交互组织',['标识：名称 + 参数','发现 / 获取：list / get','用户选择是否使用','例：报告比较模板'])
    for x in [270,750,1230]: c.line(x,420,x,490)
    c.box(55,490,1390,110,'Host 组合与校验',['模板组织任务 → 读取候选内容 → 调用分析动作 → 选择结果进入模型上下文'],fill='#eaf1fa')
    c.box(55,665,850,195,'客户端输入：通过 MRTR 返回',['elicitation：向用户征询；须声明所支持模式','sampling / roots：已弃用但仍在规范；仍须走 MRTR','不是独立的服务端 JSON-RPC 请求'],fill='#e9f5f1')
    c.box(950,665,495,195,'可选扩展（不等于核心必备）',['Tasks：持久任务句柄','Apps：工具关联交互界面','须双方支持；否则回退或拒绝'],fill='#fff4e5')
    c.line(480,665,480,600,TEAL); c.line(1190,665,1190,600,TEAL)
    c.text(55,892,'框间箭头仅表示参与宿主组合，不表示消息方向；MRTR 仅适用于左下输入框。',22,MUTED)
    c.text(55,935,'依据：[14]–[24]。三类“控制”是交互定位，不是越过宿主策略的权限。',22,MUTED)
    checks.append(c.save('capabilities'))
    c=Canvas(1010); c.title('03','MRTR：先返回输入需求，再发独立请求','MCP 2026-07-28 · tools/call 示意；每次请求均携带版本与客户端能力')
    for x,t in [(170,'用户'),(650,'Host / Client'),(1270,'Server')]:
        c.box(x-130,155,260,65,t); c.line(x,230,x,900,color='#b9c9d9',arrow=False,dash=True)
    def msg(a,b,y,label,color=BLUE):
        c.line(a,y,b,y,color); c.text((a+b)/2,y-35,label,23,color,True)
    msg(650,1270,270,'① tools/call · id = analysis-1')
    msg(1270,650,365,'② input_required · inputRequests',TEAL)
    c.text(960,387,'响应 id = analysis-1；可带 requestState',20,MUTED,True)
    c.box(720,425,490,65,'第一次请求已结束',fill='#e9f5f1')
    msg(650,170,530,'③ 呈现 elicitation 问题')
    msg(170,650,620,'④ 接受 / 拒绝 / 取消',TEAL)
    msg(650,1270,725,'⑤ 若继续：tools/call · id = analysis-2')
    c.text(960,747,'原参数 + inputResponses；原样回传已有状态',20,MUTED,True)
    msg(1270,650,850,'⑥ complete · id = analysis-2',TEAL)
    c.text(55,930,'不同 ID 表示独立请求；客户端可不继续。requestState 不提供“恰好一次”保证。',24)
    c.text(55,972,'依据：[17][18]。时序为教学示意，不是服务运行日志。',21,MUTED)
    checks.append(c.save('sequence'))
    print(json.dumps(checks,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
