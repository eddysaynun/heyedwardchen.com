# 研究方法、规范冲突与验证边界

## 对象与证据策略

这是一篇协议机制综述，不是 SDK 教程、服务端实现、兼容性认证或产品推荐。论证顺序采用已批准的八节大纲；案例、JSON 和三图均为自制教学示意。

核心固定在 MCP 2026-07-28，仓库提交为 `222640c8e771dd57f41e655d3c3eef6e5dec8b34`。延续已有 31 项来源编号，再补入 OpenAPI 3.1.1、OpenAI function calling 官方文档及当前取消细则，共 34 项。所有来源都从已保存原文或补取的一手原文实际读取；逐项路径、哈希与阅读范围见 `sources-final.json`。阅读选段不冒充通读整套规范。`ledger.json` 每项保留一个经脚本匹配原文的短证据锚点；锚点不是该来源全部论证的替代品。

继续写作时复核了原 HANDOFF，而非把其结论直接作为事实。原 `upstream` 是导出的文件树，当前目录本身没有 `.git`，所以不能用该目录的 `git rev-parse` 证明提交。另从固定 raw commit 重新取回 JSON schema、MRTR 和 HTTP 绑定并逐字节比较，三项一致，结果在 `pin-recheck.json`。这三项补查不等于重新下载全部证据。原来的规范 HTML、RFC 全文等只留在研究目录，不收入交付包。

`native-mcp` 只用于了解工具背景；没有使用它的初始化、连接或 SDK 常识替代本修订版规范，没有安装、连接 MCP 服务或改 Hermes 配置。OpenAPI/function calling 比较只限已读接口描述与应用—模型调用流程，不把任何一家模型平台当成通用协议标准。

## 逐条核查的易混淆点

| 检查项 | 本文采用的解释与依据 | 验证方式与边界 |
| --- | --- | --- |
| 初始化 | 2026-07-28 没有必需握手；版本和客户端能力逐请求声明；2025-11-25 的初始化流程仅作标明版本的历史对照。[4][6][8] | 阅读细则与类型；没有运行双版本服务器。 |
| 发现 | 服务端 MUST 实现 `server/discover`；客户端 MAY 调用；版本错误为 -32022，并提供 supported。[6][7] | 阅读规范；非在线发现测试。 |
| 元数据 | protocolVersion/clientCapabilities 必需；clientInfo 可选且 SHOULD 提供，自报而非认证。[4][5] | 示例 schema 与额外断言。 |
| 无状态 | 无协议会话不等于无业务状态；跨请求状态需显式标识，不能依赖连接历史。[4] | 机制分析；没有持久化或并发实验。 |
| MRTR | 只有 tools/call、resources/read、prompts/get 可返回 input_required；本次能力约束输入类型；重试新 ID，状态原样回传。[17] | 静态完整往返示例和变异反例。 |
| 反向交互 | stdio 和当前 HTTP SSE 均不允许独立服务端 JSON-RPC 请求；嵌入输入对象不带独立信封。[9][10][17] | 类型与条款交叉阅读，检查示例嵌套对象。 |
| HTTP 生命周期 | 独立 POST、请求作用域 JSON/SSE、subscriptions/listen；不支持旧式 GET 推送、session ID 或 Last-Event-ID 恢复。[10] | 绑定示意只查头/正文，不做网络实验。 |
| 取消 | 当前 HTTP 关闭 SSE 是取消；stdio 用 cancelled 通知；旧版断连 SHOULD NOT 当取消。[9][10][13][34] | 阅读限定条件，不声称实际取消或回滚已验证。 |
| ID 与 schema | 文字要求字符串/整数；TypeScript 使用 string 或 number 的类型表达；实际生成 JSON Schema 的 RequestId 已是 string/integer。 | 原 HANDOFF 中“schema number 不保证整数”的泛化不适用于实际这份 JSON Schema；复读后纠正。脚本确认 1.5 被官方 JSON Schema 拒绝，不把旧交接概述当事实。 |
| resultType | 当前发送端必需；缺省 complete 是旧版本接收兼容；未声明扩展的未知值无效。[4][5] | 生成 schema 对 resultType 是 string，不穷尽规范；额外检查未知值及 input_required 至少一个输入/状态字段。 |
| 弃用与扩展 | sampling、roots、logging 仍在规范但已弃用；不等于已删除或自动成为扩展。Tasks/Apps 是需双方支持的扩展。[19]–[24] | 仅读官方固定概览，未声称检查 ext-tasks/ext-apps 全部字段或实现。 |
| 授权范围 | 授权整体 OPTIONAL；HTTP SHOULD 遵循；采用框架才适用具体 MUST；stdio SHOULD NOT 照搬。[25]–[29] | 阅读原文；未执行 OAuth、PKCE、令牌或用户身份测试。 |
| 状态安全 | 影响权限或业务的 requestState 必须完整性保护；有效期、主体和原请求绑定不能单独保证一次性。[17] | 示例只测试原样回传；不包含真实加密状态，不验证密码学或反重放。 |

## 保留而不掩盖的规范张力

1. **总览的 initialization 残留。** [1] 的 extensions 段仍有初始化协商说法；[6] 版本细则、[22] 扩展概览的当前示例和 [5] 类型采用逐请求声明。本文按具体机制细则解释；不把概览残留拼入现行时序。
2. **异常错误的 null ID。** JSON-RPC 2.0 [3] 对无法辨认 ID 的错误要求 null；MCP [4][5][10] 允许省略且不接受 null。正文显式指出异常路径差异，未声称完全无差异地实现底层规范。
3. **授权页 GET 示例。** [25] 展示令牌携带方式时用了 GET /mcp；当前 HTTP 绑定 [10] 使用 POST 且不提供旧式 GET 推送。本文只取其 Authorization 头义务，不把该示例当成当前方法规则。
4. **生成类型与行为条款并非同一检查。** JSON Schema 可以约束 ID 类型，却不能跨消息证明新旧 ID 不同；InputRequiredResult 的字段描述含“至少一项”，其结构 required 只列 resultType。故对后一义务额外断言；不能以 schema 验证成功代称完整官方认证。
5. **取消概览与传输细则。** [34] 开头以通知介绍取消，但同页明确按传输分流；HTTP 无需 cancelled 消息、stdio 必须发送。正文依传输特定条款陈述，并保留协作停止与竞态边界。

## 示例解释与 SHOULD 选择

- 正文只有 request/result 两个 JSON 块，与 `examples/request.json` 和 `examples/result.json` 逐对象一致。
- 包内另有 MRTR 的 input/retry/final 和工具描述，总计五条不同消息及一份 Tool 描述通过相应官方定义验证；HTTP binding 是自制描述，不冒充官方 MCP 消息类型。
- `opaque-demo-state-not-a-security-token` 是明确的占位字符串，既不是加密令牌，也不能用于真实权限逻辑。
- 当前示意只展示结果摘要，未依旧客户端兼容建议把 structuredContent 再序列化为文本；该建议为 SHOULD，不是当前结构 MUST。没有宣称这两个示例完整覆盖旧客户端降级。
- 两个请求都含 clientInfo；表单使用显式 form 模式；本例不声明扩展，因此只接受已知核心 resultType；不示范复杂表单、二进制、安全 URL 或自定义镜像头。
- 工具 URI、指标名和输出均为教学构造，检查形状不证明有真实报告、真实工具或真实统计结果。

## 验证方法与已知限度

`verify.py` 执行：八节与字数；34 项编号、标题、URL 顺序和证据存在性；三图相对路径；两段正文 JSON 同包内示例一致；五条消息及 Tool 的官方 schema；输入/输出子 schema；MRTR 关联、能力、状态回传；示意 HTTP 头镜像；12 个故意破坏的负例；离线 HTML 的图片、代码块及有序参考列表；若存在 MANIFEST 则验证全部包成员哈希。

`grounded-citations` 原始句子划分以英语空格和标点为主，不能把其原始覆盖率直接当作中文正文覆盖率。独立检查使用中文段落统计，并报告没有引用的作者综合结论；为运行 skill 的 strict/evidence 检查，局部校验副本只将中文句末标点和紧随的引用规范化为英语分句形式，不改交付正文。34 个短引文锚点均由工具在真实原文中确认，编号检查不等于逐句自动事实核验。

三图经 `vision_analyze` 逐张检查，修正架构图小框底部留白、能力图箭头语义说明和时序图继续分支标注后，再逐张验收。PNG 是不依赖字体或插件的交付基准，SVG 提供可编辑版本；不同系统编辑 SVG 时可能需要中文字体替代。所有图都由本包脚本绘制，非上游图片拷贝。

正文 HTML 使用现有站点中 unified/remark/rehype 依赖只读离线生成，未执行 sync、build 或 deploy，也未复制到站点或 Obsidian。它验证 Markdown 正文结构，不等于完整 Astro 构建或生产样式验收。

完整原文仅供本地研究。包内唯一完整上游验证代码是未修改的 schema.json，随附固定提交原 LICENSE（上游处于 MIT/Apache-2.0 过渡，不简化成单一 MIT 声明）；来源与哈希在版本清单。其余为短证据锚点、原创文章、图及自制验证程序。
