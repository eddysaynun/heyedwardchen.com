#!/usr/bin/env python3
"""Offline checks for this article's fixtures, NOT an MCP conformance suite.
Requires Python 3.10+ and jsonschema; never starts an MCP process or sends HTTP.
Run: python research/mcp-protocol-mechanisms/verify.py --root .
"""
import argparse, copy, hashlib, json, re, struct
from pathlib import Path
from html.parser import HTMLParser
from jsonschema import Draft202012Validator

SLUG='mcp-protocol-mechanisms'
VERSION='2026-07-28'
SCHEMA_SHA='edbb197ed0f92e90d658866e23cf76f107df0caac5ce25c2b9e64e1ca9a6314a'
P='io.modelcontextprotocol/'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,msg):
    if not ok: raise ValueError(msg)
def load(p): return json.loads(p.read_text())

def validate_request(v):
    require(isinstance(v,dict),'single message, not batch')
    require(v.get('jsonrpc')=='2.0','jsonrpc version')
    require(type(v.get('id')) in (str,int),'request id must be string/integer, not null/bool')
    require(v.get('method')=='tools/call','fixture operation')
    meta=v['params']['_meta']
    require(meta[P+'protocolVersion']==VERSION,'protocol revision')
    require(isinstance(meta[P+'clientCapabilities'],dict),'capabilities are per-request')

def validate_result(v):
    require(('result' in v) != ('error' in v),'result/error exclusive')
    require(type(v.get('id')) in (str,int),'known request id')
    if 'result' not in v: return
    result=v['result']; kind=result['resultType']
    require(kind in ['complete','input_required'],'unknown resultType without extension')
    if kind=='input_required':
        require('inputRequests' in result or 'requestState' in result,'MRTR requires inputRequests or requestState')
        for obj in result.get('inputRequests',{}).values():
            require('jsonrpc' not in obj and 'id' not in obj,'nested input is not independent JSON-RPC envelope')

def validate_roundtrip(req,need,retry,final):
    validate_request(req);validate_request(retry);validate_result(need);validate_result(final)
    require(need['id']==req['id'] and final['id']==retry['id'],'response correlation')
    require(req['id']!=retry['id'],'retry must have a new id')
    require(req['method'] in ['tools/call','resources/read','prompts/get'],'MRTR method restriction')
    require(retry['method']==req['method'],'retry original method')
    for k in ['name','arguments']: require(retry['params'][k]==req['params'][k],'preserve original params')
    result=need['result']; p=retry['params']
    if 'requestState' in result: require(p.get('requestState')==result['requestState'],'echo state exactly')
    else: require('requestState' not in p,'must not invent state')
    for key,v in result.get('inputRequests',{}).items():
        require(v['method']=='elicitation/create','fixture input method')
        caps=req['params']['_meta'][P+'clientCapabilities']
        require('form' in caps.get('elicitation',{}),'fixture declares form support')
        require(key in p['inputResponses'],'input key correlation')
        reply=p['inputResponses'][key]
        require(reply['action'] in ['accept','decline','cancel'],'elicitation action')
        if reply['action']=='accept': Draft202012Validator(v['params']['requestedSchema']).validate(reply['content'])

def validate_headers(req,binding):
    require(binding['method']=='POST','current transport POST')
    h={k.lower():v for k,v in binding['headers'].items()}
    require(h['content-type']=='application/json','content type')
    require({'application/json','text/event-stream'} <= {x.strip() for x in h['accept'].split(',')},'accept both response forms')
    require(h['mcp-protocol-version']==req['params']['_meta'][P+'protocolVersion'],'version mirror')
    require(h['mcp-method']==req['method'],'method mirror')
    require(h['mcp-name']==req['params']['name'],'name mirror')

class HTMLCheck(HTMLParser):
    def __init__(self): super().__init__(); self.images=[];self.ols=0;self.lis=0;self.h2=0;self.code=0
    def handle_starttag(self,t,a):
        d=dict(a)
        if t=='img':self.images.append(d['src'])
        if t=='ol':self.ols+=1
        if t=='li':self.lis+=1
        if t=='h2':self.h2+=1
        if t=='code' and d.get('class')=='language-json':self.code+=1

def run(root):
    research=root/'research'/SLUG; article=root/'drafts'/f'{SLUG}.md'
    t=article.read_text(); prose,refs=t.split('## 参考资料\n',1)
    sections=re.findall(r'^## ([1-8])\. (.+)$',prose,re.M)
    require([n for n,_ in sections]==list('12345678'),'eight ordered sections')
    require(t.startswith('---\n') and 'pinned: false' in t.split('---',2)[1],'frontmatter')
    require(t.count('```')==4 and len(re.findall(r'^```json$',t,re.M))==2,'two balanced JSON blocks')
    body=prose[prose.index('## 1.'):]
    body=re.sub(r'```.*?```','',body,flags=re.S)
    body=re.sub(r'^#+.*$','',body,flags=re.M)
    body=re.sub(r'!\[.*?\]\([^\n]*?\)','',body)
    count=len(re.findall(r'[\u3400-\u9fff]',body))
    require(6000<=count<=8000,'6000–8000 Han body characters')
    citation_ids={int(n) for n in re.findall(r'\[(\d+)\](?!\()',prose)}
    ledger=load(research/'ledger.json')['sources']; byid={s['id']:s for s in ledger}
    require(citation_ids==set(byid),'references/citation IDs exactly cover ledger')
    listed=re.findall(r'^(\d+)\. \[([^\]]+)\]\(([^\s)]+)\)$',refs,re.M)
    require(len(listed)==len(ledger),'ordered reference count')
    for (n,title,url),source in zip(listed,ledger):
        require((int(n),title,url)==(source['id'],source['title'],source['url']),'reference number/title/url match')
        require(bool(source.get('quotes')),'source evidence anchor')
    paras=[p for p in re.split(r'\n\s*\n',body) if len(re.findall(r'[\u3400-\u9fff]',p))>=20]
    covered=[p for p in paras if re.search(r'\[\d+\]',p)]
    images=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',t)
    require(len(images)==3,'three image references')
    figure_report=[]
    for image in images:
        target=(article.parent/image).resolve();require(target.is_relative_to(root.resolve()),'image inside bundle')
        data=target.read_bytes();require(data[:8]==b'\x89PNG\r\n\x1a\n','PNG signature')
        w,h=struct.unpack('>II',data[16:24]);require(w==1500 and h>=800,'figure resolution')
        require(target.with_suffix('.svg').exists(),'editable SVG present')
        figure_report.append({'path':image,'width':w,'height':h,'sha256':digest(target)})
    schema_path=research/'validation/schema.json'; require(digest(schema_path)==SCHEMA_SHA,'official schema pinned hash')
    schema=load(schema_path); Draft202012Validator.check_schema(schema)
    def official(obj,typ):
        Draft202012Validator({**schema,'$ref':'#/$defs/'+typ}).validate(obj)
    fixtures={p.stem:load(p) for p in (research/'examples').glob('*.json')}
    schemas={'request':'CallToolRequest','result':'CallToolResultResponse','mrtr-input':'CallToolResultResponse','mrtr-retry':'CallToolRequest','mrtr-final':'CallToolResultResponse','tool':'Tool'}
    for name,typ in schemas.items():official(fixtures[name],typ)
    req,res,need,retry,final,tool=[fixtures[k] for k in ['request','result','mrtr-input','mrtr-retry','mrtr-final','tool']]
    blocks=[json.loads(b) for b in re.findall(r'```json\n(.*?)\n```',t,re.S)]
    require(blocks==[req,res],'article JSON equals packaged fixtures')
    validate_request(req);validate_result(res)
    require(req['id']==res['id'],'direct response correlation')
    validate_roundtrip(req,need,retry,final)
    validate_headers(req,fixtures['http-binding'])
    for key in ['inputSchema','outputSchema']:Draft202012Validator.check_schema(tool[key])
    for q in [req,retry]:Draft202012Validator(tool['inputSchema']).validate(q['params']['arguments'])
    for a in [res,final]:Draft202012Validator(tool['outputSchema']).validate(a['result']['structuredContent'])
    # Negative controls: passing fixtures alone would not demonstrate that checks detect errors.
    negative=[]
    def rejects(name,fn):
        try:fn()
        except (ValueError,KeyError,TypeError) as e:negative.append({'id':name,'rejected':True,'by':type(e).__name__})
        except Exception as e:
            if e.__class__.__name__=='ValidationError':negative.append({'id':name,'rejected':True,'by':'JSONSchema'})
            else:raise
        else:raise ValueError('negative control unexpectedly accepted: '+name)
    x=copy.deepcopy(req);del x['params']['_meta'];rejects('missing-meta',lambda:official(x,'CallToolRequest'))
    for invalid,n in [(None,'null-id'),(1.5,'fractional-id')]:
        x=copy.deepcopy(req);x['id']=invalid;rejects(n,lambda:official(x,'CallToolRequest'))
    rejects('batch-array',lambda:official([req],'JSONRPCMessage'))
    x=copy.deepcopy(res);x['result']['resultType']='invented';rejects('unknown-result-type',lambda:validate_result(x))
    x=copy.deepcopy(need);x['result']={'resultType':'input_required'};rejects('empty-input-required',lambda:validate_result(x))
    x=copy.deepcopy(retry);x['id']=req['id'];same_final=copy.deepcopy(final);same_final['id']=req['id'];rejects('same-retry-id',lambda:validate_roundtrip(req,need,x,same_final))
    x=copy.deepcopy(retry);x['params']['requestState']='changed';rejects('changed-state',lambda:validate_roundtrip(req,need,x,final))
    x=copy.deepcopy(req);x['params']['_meta'][P+'clientCapabilities']={};rejects('undeclared-elicitation',lambda:validate_roundtrip(x,need,retry,final))
    x=copy.deepcopy(fixtures['http-binding']);x['headers']['Mcp-Name']='other';rejects('header-body-mismatch',lambda:validate_headers(req,x))
    x=copy.deepcopy(need);x['result']['inputRequests']['basis']['id']='illegal-envelope';rejects('independent-input-envelope',lambda:validate_result(x))
    x=copy.deepcopy(res);x['error']={'code':-32603,'message':'error'};rejects('result-error-both',lambda:validate_result(x))
    h=HTMLCheck();h.feed(article.with_suffix('.html').read_text())
    require(h.images==images,'HTML image references preserved')
    require(h.ols==1 and h.lis==34 and h.code==2,'HTML references and code render')
    htmlrefs=article.with_suffix('.html').read_text().split('参考资料</h2>',1)[1]
    hrefs=re.findall(r'href="([^\"]+)"',htmlrefs)
    require(hrefs==[s['url'] for s in ledger],'HTML reference URL order')
    integrity=None
    manifest=root/'MANIFEST.sha256.json'
    if manifest.exists():
        declared=load(manifest)
        actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=manifest}
        require(actual==set(declared),'manifest covers every member except itself')
        for name,sha in declared.items():require(digest(root/name)==sha,'member hash '+name)
        integrity={'hashed_members':len(declared),'self_excluded':'MANIFEST.sha256.json','passed':True}
    return {'status':'passed','scope':'Article and static example verification; NOT full official conformance certification',
        'body_han_characters':count,'count_rule':'sections 1–8; U+3400–U+9FFF; excludes headings, figures/captions, fenced code, abstract, version scope, references; retains Chinese prose inside inline code',
        'sections':[title for _,title in sections],'sources':len(ledger),'source_evidence_anchors':len(ledger),
        'citation_paragraphs':{'total':len(paras),'with_citations':len(covered),'uncited_are_author_synthesis':[p[:100] for p in paras if p not in covered]},
        'figures':figure_report,'official_schema_sha256':SCHEMA_SHA,'schema_checks':[{'fixture':n,'type':typ,'passed':True} for n,typ in schemas.items()],
        'article_json_blocks_checked':len(blocks),'negative_controls':negative,
        'additional_checks':['id type and direct response correlation','MRTR permitted method, new ID and response correlation','MRTR input/result keys and declared form capability','opaque state exact echo (NOT cryptographic integrity)','elicitation form submitted content','tool input/output JSON schemas and fixture values','POST/Accept/Content-Type and three mirrored headers','result/error exclusivity and known core resultType'],
        'html':{'images':len(h.images),'reference_lists':h.ols,'references':h.lis,'json_blocks':h.code,'full_site_build':False},
        'archive_integrity':integrity,'article_sha256':digest(article),
        'not_verified':['live MCP client/server interoperability','network cancellation or disconnect race behavior','OAuth issuer/token/PKCE flows','requestState integrity cryptography, replay prevention or single-use enforcement','third-party business effects or idempotency','full Tasks/Apps extension conformance','production site build or deployment']}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path.cwd());p.add_argument('--output',type=Path)
    args=p.parse_args(); report=run(args.root.resolve()); text=json.dumps(report,ensure_ascii=False,indent=2)+'\n'
    if args.output:args.output.write_text(text)
    print(text)
