#!/usr/bin/env python3
"""Build an allowlisted bundle and independently extract/recheck it.
This is an article packaging tool, not an MCP server. No network calls.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
SLUG='mcp-protocol-mechanisms'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);ap.add_argument('--scratch',type=Path,required=True);args=ap.parse_args()
    root=args.root.resolve();r=root/'research'/SLUG
    assert args.scratch.is_dir(),'explicit existing scratch required'
    stage=Path(tempfile.mkdtemp(prefix='mcp-bundle-stage-',dir=args.scratch))
    unpack=Path(tempfile.mkdtemp(prefix='mcp-bundle-extract-',dir=args.scratch))
    mapping={Path('README.md'):r/'README.md'}
    for suffix in ['.md','.html']:
        rel=Path('drafts')/(SLUG+suffix);mapping[rel]=root/rel
    names=['verify.py','draw_figures.py','render.mjs','build_bundle.py','METHODOLOGY.md','ledger.json','sources-final.json','versions.json','pin-recheck.json','static-verification.json','visual-review.json','browser-review.json','normative-review.json']
    for name in names:mapping[Path('research')/SLUG/name]=r/name
    for folder in ['figures','examples','validation']:
        for src in sorted((r/folder).iterdir()):
            if src.is_file():mapping[Path('research')/SLUG/folder/src.name]=src
    for rel,src in mapping.items():
        dst=stage/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    manifest={str(rel):sha(stage/rel) for rel in sorted(mapping)}
    (stage/'MANIFEST.sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    out=root/'articles';out.mkdir(exist_ok=True)
    archive=out/(SLUG+'.zip')
    # Existing artifacts, if any, are read before replacement; original research is never removed.
    if archive.exists():
        with zipfile.ZipFile(archive) as old:
            assert old.testzip() is None
            for name in old.namelist():old.read(name)
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for src in sorted(stage.rglob('*')):
            if src.is_file():z.write(src,src.relative_to(stage))
    with zipfile.ZipFile(archive) as z:
        names=z.namelist();assert len(names)==len(set(names)),'duplicate member'
        assert z.testzip() is None,'CRC check'
        for name in names:
            p=Path(name);assert not p.is_absolute() and '..' not in p.parts,'unsafe archive path'
        z.extractall(unpack)
    expected=set(manifest)|{'MANIFEST.sha256.json'};assert set(names)==expected
    extracted= json.loads((unpack/'MANIFEST.sha256.json').read_text())
    assert extracted==manifest
    for name,value in extracted.items():assert sha(unpack/name)==value,name
    article=Path('drafts')/(SLUG+'.md')
    assert (unpack/article).read_bytes()==(root/article).read_bytes(),'manuscript mismatch'
    # Fresh process exercises code and examples from the extracted final ZIP.
    run=subprocess.run([sys.executable,'-B',str(unpack/'research'/SLUG/'verify.py'),'--root',str(unpack)],capture_output=True,text=True,cwd=unpack)
    assert run.returncode==0,run.stdout+'\n'+run.stderr
    check=json.loads(run.stdout)
    report={'status':'passed','zip':str(archive),'zip_sha256':sha(archive),'zip_bytes':archive.stat().st_size,'member_count':len(names),'hashed_member_count':len(manifest),'manifest_self_excluded':True,'zip_crc':'passed','safe_unique_members':True,'independent_extraction':str(unpack),'extracted_manuscript_equals_final_draft':True,'extracted_verifier_exit_code':run.returncode,'extracted_verification':check,'normative_source_review':json.loads((r/'normative-review.json').read_text()),'figure_visual_review':json.loads((r/'visual-review.json').read_text()),'offline_browser_review':json.loads((r/'browser-review.json').read_text()),'preserved_boundaries':['no MCP installation or server connection','no website or Obsidian edits','no publishing or git push','no Hermes configuration changes'],'full_third_party_prose_in_archive':False,'allowed_upstream_validation_artifacts':['schema.json','LICENSE']}
    report_path=out/(SLUG+'-verification.json')
    if report_path.exists():json.loads(report_path.read_text())
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'zip':str(archive),'report':str(report_path),'zip_sha256':report['zip_sha256'],'members':len(names),'body_han_characters':check['body_han_characters'],'schema_objects':len(check['schema_checks']),'negative_controls':len(check['negative_controls']),'independent_extraction':str(unpack)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
