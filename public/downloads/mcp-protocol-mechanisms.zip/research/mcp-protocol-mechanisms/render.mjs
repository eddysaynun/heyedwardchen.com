// Offline body rendering with read-only dependencies from an existing site.
// Usage: node render.mjs ROOT SITE_ROOT. No build/sync/deploy command is run.
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const root = path.resolve(process.argv[2]);
const site = path.resolve(process.argv[3]);
const load = async (pkg, file) => import(pathToFileURL(path.join(site, 'node_modules', pkg, file)).href);
const { unified } = await load('unified','index.js');
const { default: parse } = await load('remark-parse','index.js');
const { default: gfm } = await load('remark-gfm','index.js');
const { default: rehype } = await load('remark-rehype','index.js');
const { default: stringify } = await load('rehype-stringify','index.js');
const source = path.join(root,'drafts/mcp-protocol-mechanisms.md');
const md = fs.readFileSync(source,'utf8').replace(/^---\n[\s\S]*?\n---\n/, '');
const result = await unified().use(parse).use(gfm).use(rehype).use(stringify).process(md);
const output = path.join(root,'drafts/mcp-protocol-mechanisms.html');
const css = 'body{max-width:980px;margin:40px auto;padding:0 24px;font:18px/1.85 system-ui,sans-serif;color:#162b42;background:#fff}h1,h2{line-height:1.4}h2{margin-top:2em}img{display:block;width:100%;height:auto;margin:2em 0}pre{overflow:auto;background:#f3f6fa;padding:20px;font-size:14px;line-height:1.6}a{color:#225d95}li{margin:.4em 0}';
fs.writeFileSync(output,'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>理解 MCP：协议架构、交互语义与互操作边界</title><style>'+css+'</style><body>'+String(result)+'</body></html>');
console.log(JSON.stringify({output,renderer:'unified + remark-parse + remark-gfm + remark-rehype + rehype-stringify',site_dependencies_read_only:true,full_site_build:false,node:process.version,packages:Object.fromEntries(['unified','remark-parse','remark-gfm','remark-rehype','rehype-stringify'].map(p=>[p,JSON.parse(fs.readFileSync(path.join(site,'node_modules',p,'package.json'),'utf8')).version]))},null,2));
