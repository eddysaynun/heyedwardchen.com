"""Contract checks: real integration is separate from injected failures."""
import argparse
import contextlib
import io
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import wave

import audio_cli as cli

ROOT = Path(__file__).resolve().parent
SCRATCH = Path(os.environ.get('AUDIO_CLI_TEST_ROOT', str(Path.home() / '.cache' / 'reliable-agent-cli')))
COMMANDS, ARTIFACTS = [], []


def make_wav(path):
    with wave.open(str(path), 'wb') as wav:
        wav.setparams((2, 2, 44100, 0, 'NONE', 'not compressed'))
        frames = bytearray()
        for i in range(44100):
            sample = int(8000 * math.sin(2 * math.pi * 440 * i / 44100))
            frames.extend(struct.pack('<hh', sample, sample))
        wav.writeframes(frames)


class Fixture(unittest.TestCase):
    def setUp(self):
        SCRATCH.mkdir(parents=True, exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix='检查 space ', dir=SCRATCH)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source, self.target = self.root / '输入 stereo.wav', self.root / '输出 mono.wav'
        make_wav(self.source)

    def args(self):
        return ['--input', str(self.source), '--output', str(self.target), '--timeout', '10']

    def invoke(self, argv=None):
        command = [sys.executable, str(ROOT / 'audio_cli.py'), *(self.args() if argv is None else argv)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=20)
        COMMANDS.append(dict(command=command, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
        data = json.loads(result.stdout)
        self.assertEqual(len(result.stdout.strip().splitlines()), 1)
        self.assertEqual(data['code'], result.returncode)
        return data

    def in_process(self):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = cli.main(self.args())
        data = json.loads(out.getvalue())
        self.assertEqual(data['code'], code)
        self.assertEqual(len(out.getvalue().strip().splitlines()), 1)
        return data

    def assert_clean(self):
        self.assertFalse(self.target.exists())
        self.assertEqual(list(self.root.glob('.audio-cli-*')), [])


class RealIntegration(Fixture):
    def test_real_conversion_with_unicode_spaces_and_probe(self):
        data = self.invoke()
        self.assertTrue(data['ok'])
        probe = subprocess.run([cli.FFPROBE, '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(self.target)], capture_output=True, text=True, check=True)
        parsed = json.loads(probe.stdout)
        stream = parsed['streams'][0]
        self.assertEqual((stream['sample_rate'], stream['channels'], stream['codec_name']), ('16000', 1, 'pcm_s16le'))
        with wave.open(str(self.target), 'rb') as wav:
            self.assertEqual((wav.getframerate(), wav.getnchannels(), wav.getsampwidth(), wav.getnframes()), (16000, 1, 2, 16000))
            self.assertTrue(any(wav.readframes(wav.getnframes())))
        ARTIFACTS.append(dict(cli=data, probe=parsed))

    def test_existing_output_unchanged(self):
        self.target.write_bytes(b'keep this original')
        self.assertEqual(self.invoke()['code'], 6)
        self.assertEqual(self.target.read_bytes(), b'keep this original')

    def test_broken_input(self):
        self.source.write_bytes(b'not a wav')
        self.assertEqual(self.invoke()['code'], 2)
        self.assert_clean()

    def test_invalid_timeout(self):
        for value in ('0', '-1', 'nan', 'inf', 'bad'):
            with self.subTest(value=value):
                args = self.args(); args[-1] = value
                self.assertEqual(self.invoke(args)['code'], 2)
        self.assert_clean()

    def test_missing_and_unknown_arguments(self):
        for args in ([], self.args() + ['--unknown']):
            with self.subTest(args=args):
                self.assertEqual(self.invoke(args)['code'], 2)

    def test_symlink_input_rejected(self):
        real = self.root / 'real.wav'
        self.source.rename(real)
        self.source.symlink_to(real)
        self.assertEqual(self.invoke()['code'], 2)
        self.assert_clean()

    def test_output_parent_missing(self):
        self.target = self.root / 'missing' / 'result.wav'
        self.assertEqual(self.invoke()['code'], 2)

    def test_near_zero_deadline(self):
        args = self.args(); args[-1] = '0.000000001'
        self.assertEqual(self.invoke(args)['code'], 5)
        self.assert_clean()

    def test_help_is_text_exception(self):
        result = subprocess.run([sys.executable, str(ROOT / 'audio_cli.py'), '--help'], capture_output=True, text=True, check=True)
        self.assertIn('--input', result.stdout)


class FaultInjection(Fixture):
    def test_missing_dependency(self):
        with patch.object(cli, 'FFMPEG', str(self.root / 'absent')):
            self.assertEqual(self.in_process()['code'], 3)
        self.assert_clean()

    def test_backend_nonzero(self):
        with patch.object(cli, 'run_process', return_value=(1, '', 'backend detail')):
            self.assertEqual(self.in_process()['code'], 4)
        self.assert_clean()

    def test_backend_timeout(self):
        with patch.object(cli, 'run_process', side_effect=cli.CliError(5, 'backend timed out')):
            self.assertEqual(self.in_process()['code'], 5)
        self.assert_clean()

    def test_zero_exit_without_output(self):
        raw = json.dumps({'streams': [{'sample_rate': '16000', 'channels': 1, 'codec_name': 'pcm_s16le'}], 'format': {'duration': '1'}})
        with patch.object(cli, 'run_process', side_effect=[(0, '', ''), (0, raw, '')]):
            self.assertEqual(self.in_process()['code'], 7)
        self.assert_clean()

    def test_probe_rejects_wrong_and_missing_fields(self):
        cases = [
            {'streams': [], 'format': {'duration': '1'}},
            {'streams': [{'sample_rate': '44100', 'channels': 2, 'codec_name': 'pcm_s16le'}], 'format': {'duration': '1'}},
            {'streams': [{'sample_rate': '16000', 'channels': 1, 'codec_name': 'pcm_s16le'}], 'format': {'duration': 'nan'}},
            None, {}, {'streams': None},
        ]
        for data in cases:
            with self.subTest(data=data), patch.object(cli, 'run_process', return_value=(0, json.dumps(data), '')):
                with self.assertRaises(cli.CliError) as error:
                    cli.verify_output(self.source, time.monotonic() + 5)
                self.assertEqual(error.exception.code, 7)

    def test_probe_bad_json(self):
        with patch.object(cli, 'run_process', return_value=(0, '{broken', '')):
            with self.assertRaises(cli.CliError) as error:
                cli.verify_output(self.source, time.monotonic() + 5)
            self.assertEqual(error.exception.code, 7)

    def test_probe_nonzero(self):
        with patch.object(cli, 'run_process', return_value=(1, '', '')):
            with self.assertRaises(cli.CliError) as error:
                cli.verify_output(self.source, time.monotonic() + 5)
            self.assertEqual(error.exception.code, 7)

    def test_truncated_wav(self):
        self.source.write_bytes(self.source.read_bytes()[:-100])
        with self.assertRaises(cli.CliError) as error:
            cli.validate_wav(self.source)
        self.assertEqual(error.exception.code, 2)

    def test_publish_race_never_overwrites(self):
        real_link = os.link
        def race(source, target):
            Path(target).write_bytes(b'concurrent owner')
            return real_link(source, target)
        with patch.object(cli.os, 'link', side_effect=race):
            self.assertEqual(self.in_process()['code'], 6)
        self.assertEqual(self.target.read_bytes(), b'concurrent owner')
        self.assertEqual(list(self.root.glob('.audio-cli-*')), [])


class ProcessRunner(Fixture):
    def test_bounded_real_output(self):
        code, out, err = cli.run_process([sys.executable, '-c', 'import sys; print("x"*200000); print("y"*200000,file=sys.stderr)'], time.monotonic() + 5)
        self.assertEqual(code, 0)
        self.assertLessEqual(len(out.encode()), cli.STDOUT_LIMIT)
        self.assertLessEqual(len(err.encode()), cli.STDERR_LIMIT)

    def test_real_timeout_reaps_child(self):
        pidfile = self.root / 'pid.txt'
        script = 'import os,time,pathlib; pathlib.Path(' + repr(str(pidfile)) + ').write_text(str(os.getpid())); time.sleep(10)'
        with self.assertRaises(cli.CliError) as error:
            cli.run_process([sys.executable, '-c', script], time.monotonic() + 1)
        self.assertEqual(error.exception.code, 5)
        pid = int(pidfile.read_text())
        with self.assertRaises(ProcessLookupError):
            os.kill(pid, 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
