import json
import subprocess
import wave
from audio_cli import FFPROBE

path = 'example-data/output mono.wav'
result = subprocess.run(
    [FFPROBE, '-v', 'error', '-select_streams', 'a',
     '-show_entries', 'stream=codec_name,sample_rate,channels:format=duration',
     '-of', 'json', path],
    capture_output=True, text=True, check=True, timeout=10,
)
data = json.loads(result.stdout)
assert len(data['streams']) == 1
stream = data['streams'][0]
assert (stream['sample_rate'], stream['channels'], stream['codec_name']) == ('16000', 1, 'pcm_s16le')
with wave.open(path, 'rb') as wav:
    assert (wav.getframerate(), wav.getnchannels(), wav.getsampwidth(), wav.getnframes()) == (16000, 1, 2, 16000)
    assert any(wav.readframes(wav.getnframes()))
print(json.dumps(data, ensure_ascii=False, indent=2))
