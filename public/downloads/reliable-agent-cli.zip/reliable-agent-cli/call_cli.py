import json
from pathlib import Path
import subprocess
import sys

result = subprocess.run(
    [sys.executable, str(Path(__file__).with_name('audio_cli.py')),
     '--input', 'example-data/input stereo.wav',
     '--output', 'example-data/output mono.wav', '--timeout', '10'],
    capture_output=True, text=True, timeout=20,
)
reply = json.loads(result.stdout)
assert reply['code'] == result.returncode
print(json.dumps(reply, ensure_ascii=False))
if not reply['ok']:
    raise SystemExit(result.returncode)
