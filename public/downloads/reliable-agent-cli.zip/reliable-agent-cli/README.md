# Reliable Agent CLI：音频转换示例

将本地 PCM WAV 转换为 **16 kHz、单声道、pcm_s16le WAV**。Python 只使用标准库，真实转换由 FFmpeg 完成，验收使用 ffprobe 和 Python wave。没有调用模型，也不是 CLI-Anything 的生成产物。

## 文件

- `audio_cli.py`：命令实现。
- `cli_checks.py`：真实集成、内部故障注入和子进程管理测试。
- `verify.py`：运行测试并生成真实证据。
- `results.json`：作者运行环境中的原始记录；不是用户机器的结果。
- `create_input.py`、`call_cli.py`、`inspect_output.py`：文章中的三个可执行示例。

## 环境与运行

验证环境：Apple Silicon macOS，FFmpeg / ffprobe 8.0.1。`audio_cli.py` 顶部的 `FFMPEG` 和 `FFPROBE` 固定为 `/opt/homebrew/bin/ffmpeg` 与 `/opt/homebrew/bin/ffprobe`。安装在其他位置时，将这两个常量改为自己信任的绝对路径；没有公开的任意后端命令或附加选项入口。不要指向不可信二进制。

解压后，在本目录执行：

```sh
python3 create_input.py
python3 call_cli.py
python3 inspect_output.py
python3 -m unittest -v cli_checks
python3 verify.py
```

前三步创建当前目录下的 `example-data/input stereo.wav` 和 `example-data/output mono.wav`，拒绝覆盖已有文件。再次运行转换会返回冲突，而不是自动覆盖。需要重跑时自行选择新目录或确认后处理旧文件。

测试临时目录默认 `~/.cache/reliable-agent-cli/`，也可用 `AUDIO_CLI_TEST_ROOT` 指定。作者验证使用 Hermes 的 scratch 路径，不使用 `/tmp`。`verify.py` 会更新当前目录的 `results.json`，并保留一组音频证据。

## 命令契约

```sh
python3 audio_cli.py --input 'input stereo.wav' --output 'output mono.wav' --timeout 30
```

`--input` 与 `--output` 必填；`--timeout` 必须是正且有限的数。允许中文、空格和相对路径。输入必须是非符号链接的普通 `.wav` 文件，能被标准库 wave 作为 PCM WAV 完整读取。输出父目录必须存在，扩展名必须是 `.wav`。已有文件、目录或符号链接一律不覆盖。

除 `--help` 外，正常成功和预期错误均在 stdout 输出一行 JSON；stderr 仅提供简短诊断。成功字段为 `ok/code/output/sample_rate/channels/codec/duration`，错误字段为 `ok/code/error`。

退出码：0 验收发布成功；2 参数/输入/目录错误；3 依赖缺失；4 后端执行失败；5 超时；6 输出冲突；7 产物验收或原子发布失败。这是本示例约定，不是通用标准。

## 可靠性与边界

- 输入先完整验证；输出先写同目录临时文件。
- subprocess 参数列表、不使用 shell、禁用 stdin 交互、固定 WAV 解码器及 file 协议。
- FFmpeg 零退出码之后，继续用 ffprobe 验证采样率、声道、编码及有限正时长，再用 wave 检查声明数据是否完整。
- 合法静音可以成功。测试的合成正弦波另外检查非零样本。
- `os.link` 将已验收临时文件无覆盖地发布到最终路径。目标竞争出现时失败，不使用覆盖式 replace；不支持硬链接的文件系统失败关闭。
- FFmpeg、ffprobe 共用 monotonic deadline。超时终止并回收直接子进程。不是包含输入全量扫描的硬实时上限，也不管理孙进程。
- 并发排空 stdout/stderr，分别只保留 64 KiB / 4 KiB 尾部；后端原始诊断不转发给模型，避免泄漏元数据。
- 信任本机二进制和工作目录；不防恶意并发替换输入或父目录。不是沙箱、不保证断电持久性、不提供跨调用幂等。强杀或断电可能遗留临时文件。
- 不保证内容保真、全部输入格式或所有 WAV 子格式。固定为 16 kHz 单声道不是对所有语音识别服务的通用要求。

## 证据解释

`results.json` 记录实际测试 ID、分类、原始输出、版本、命令、独立探测、样本属性和哈希。`RealIntegration` 不 mock 后端；`FaultInjection` 注入内部故障，不能算真实后端故障实验；`ProcessRunner` 检查真实子进程的日志上限与超时回收。接近零的 deadline 可能在启动子进程前到期，不能单凭这项测试证明已启动的 FFmpeg 被杀死。

所有测试通过也不等于 Agent 任务成功率为 100%。本示例没有模型自动选参或多轮恢复实验。
