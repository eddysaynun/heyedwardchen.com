#!/usr/bin/env python3
"""Run the suite and persist actual evidence, never synthesized responses."""
import collections
import datetime
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import unittest
import wave

import audio_cli
import cli_checks as tests

ROOT = Path(__file__).resolve().parent


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item.id()


def command(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=30)
    return dict(command=args, returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)


def main():
    tests.SCRATCH.mkdir(parents=True, exist_ok=True)
    suite = unittest.defaultTestLoader.loadTestsFromModule(tests)
    ids = list(flatten(suite))
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    print(log.getvalue(), end='')
    versions = [command([binary, '-version']) for binary in (audio_cli.FFMPEG, audio_cli.FFPROBE)]
    evidence_dir = Path(tempfile.mkdtemp(prefix='保留 evidence ', dir=tests.SCRATCH))
    source, target = evidence_dir / '输入 stereo.wav', evidence_dir / '输出 mono.wav'
    tests.make_wav(source)
    conversion = command([sys.executable, str(ROOT / 'audio_cli.py'), '--input', str(source), '--output', str(target), '--timeout', '10'])
    probe = command([audio_cli.FFPROBE, '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(target)])
    artifact = None
    if conversion['returncode'] == 0 and probe['returncode'] == 0:
        with wave.open(str(target), 'rb') as wav:
            payload = wav.readframes(wav.getnframes())
            artifact = dict(path=str(target), bytes=target.stat().st_size,
                            sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                            sample_rate=wav.getframerate(), channels=wav.getnchannels(),
                            sample_width=wav.getsampwidth(), frames=wav.getnframes(),
                            nonzero_samples=any(payload), probe=json.loads(probe['stdout']))
    artifact_ok = bool(artifact and (artifact['sample_rate'], artifact['channels'], artifact['sample_width'], artifact['frames'], artifact['nonzero_samples']) == (16000, 1, 2, 16000, True))
    red_path = tests.SCRATCH / 'tdd-red.json'
    report = dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  python=platform.python_version(), platform=platform.platform(),
                  success=result.wasSuccessful() and artifact_ok and all(v['returncode'] == 0 for v in versions),
                  tests=dict(run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                             skipped=len(result.skipped), ids=ids,
                             categories=dict(collections.Counter(i.split('.')[-2] for i in ids)),
                             raw_output=log.getvalue()),
                  versions=versions, integration_commands=tests.COMMANDS,
                  integration_observations=tests.ARTIFACTS,
                  retained_evidence=dict(input=str(source), conversion=conversion, probe_command=probe, artifact=artifact),
                  tdd_red=json.loads(red_path.read_text()) if red_path.exists() else None,
                  scope='No model calls; not an agent success-rate experiment. FaultInjection uses mocks; RealIntegration does not mock backends. ProcessRunner has real bounded-log and child-timeout/reap tests.')
    (ROOT / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(success=report['success'], tests_run=result.testsRun,
                          categories=report['tests']['categories'], artifact=artifact,
                          results=str(ROOT / 'results.json')), ensure_ascii=False))
    return 0 if report['success'] else 1


if __name__ == '__main__':
    sys.exit(main())
