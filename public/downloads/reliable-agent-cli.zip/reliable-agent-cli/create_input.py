from pathlib import Path
import math
import struct
import wave

folder = Path('example-data')
folder.mkdir(exist_ok=True)
source = folder / 'input stereo.wav'
frames = bytearray()
for i in range(44100):
    value = int(8000 * math.sin(2 * math.pi * 440 * i / 44100))
    frames.extend(struct.pack('<hh', value, value))
with source.open('xb') as handle, wave.open(handle, 'wb') as wav:
    wav.setparams((2, 2, 44100, 0, 'NONE', 'not compressed'))
    wav.writeframes(frames)
print(source.resolve())
