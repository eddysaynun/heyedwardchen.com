#!/usr/bin/env python3
"""Small local PCM-WAV converter. Stdout is one JSON object, except --help."""
import argparse
import json
import math
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import threading
import time
import wave

FFMPEG = '/opt/homebrew/bin/ffmpeg'
FFPROBE = '/opt/homebrew/bin/ffprobe'
STDERR_LIMIT = 4096
STDOUT_LIMIT = 65536


class CliError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


class Parser(argparse.ArgumentParser):
    def error(self, message):
        # Do not reflect arbitrary user-supplied tokens (possibly secrets).
        raise CliError(2, 'invalid arguments; use --help')


def positive_timeout(value):
    try:
        number = float(value)
    except ValueError:
        raise argparse.ArgumentTypeError('timeout must be positive and finite')
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError('timeout must be positive and finite')
    return number


def run_process(command, deadline):
    """Drain both pipes concurrently, retaining only bounded tails; no shell.

    Timeout covers FFmpeg and ffprobe together. Kill and reap the direct child.
    Fixed binaries are trusted: process-tree sandboxing is deliberately absent.
    """
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise CliError(5, 'backend timed out')
    try:
        proc = subprocess.Popen(command, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except FileNotFoundError:
        raise CliError(3, 'required backend is missing')
    except OSError:
        raise CliError(4, 'could not start backend')
    buffers = [bytearray(), bytearray()]

    def drain(pipe, buffer, limit):
        try:
            while True:
                block = pipe.read(8192)
                if not block:
                    break
                buffer.extend(block)
                del buffer[:-limit]
        finally:
            pipe.close()

    threads = [threading.Thread(target=drain, args=(pipe, buffer, limit))
               for pipe, buffer, limit in zip((proc.stdout, proc.stderr), buffers,
                                              (STDOUT_LIMIT, STDERR_LIMIT))]
    for thread in threads:
        thread.start()
    try:
        proc.wait(timeout=max(0, deadline - time.monotonic()))
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        raise CliError(5, 'backend timed out')
    finally:
        for thread in threads:
            thread.join()
    return proc.returncode, *(bytes(b).decode('utf-8', errors='replace') for b in buffers)


def validate_wav(path, output=False):
    """Validate PCM header and full declared payload, with bounded memory."""
    code = 7 if output else 2
    try:
        with wave.open(str(path), 'rb') as wav:
            if wav.getcomptype() != 'NONE' or wav.getnframes() <= 0:
                raise ValueError('empty or compressed WAV')
            if output and (wav.getframerate(), wav.getnchannels(), wav.getsampwidth()) != (16000, 1, 2):
                raise ValueError('wrong output parameters')
            remaining = wav.getnframes() * wav.getnchannels() * wav.getsampwidth()
            while remaining:
                block = wav.readframes(8192)
                if not block or len(block) > remaining:
                    raise ValueError('truncated WAV')
                remaining -= len(block)
    except (OSError, EOFError, wave.Error, ValueError):
        raise CliError(code, 'invalid output WAV' if output else 'invalid input PCM WAV')


def verify_output(path, deadline):
    status, raw, _tail = run_process([
        FFPROBE, '-v', 'error', '-select_streams', 'a',
        '-show_entries', 'stream=codec_name,sample_rate,channels:format=duration',
        '-of', 'json', str(path)], deadline)
    if status:
        raise CliError(7, 'output probe failed')
    try:
        data = json.loads(raw)
        streams = data['streams']
        if len(streams) != 1:
            raise ValueError('expected one audio stream')
        stream = streams[0]
        duration = float(data['format']['duration'])
        if (int(stream['sample_rate']), stream['channels'], stream['codec_name']) != (16000, 1, 'pcm_s16le'):
            raise ValueError('unexpected audio format')
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError('invalid duration')
    except (ValueError, TypeError, KeyError, IndexError, OverflowError):
        raise CliError(7, 'output probe validation failed')
    validate_wav(path, output=True)
    return dict(sample_rate=16000, channels=1, codec='pcm_s16le', duration=duration)


def convert(args):
    source, target = Path(args.input).absolute(), Path(args.output).absolute()
    try:
        if source.suffix.lower() != '.wav' or not stat.S_ISREG(source.lstat().st_mode):
            raise CliError(2, 'input must be a local regular PCM WAV, not a symlink')
        if target.suffix.lower() != '.wav' or not target.parent.is_dir():
            raise CliError(2, 'output must end in .wav in an existing directory')
        if os.path.lexists(target):
            raise CliError(6, 'output already exists')
        validate_wav(source)
    except OSError:
        raise CliError(2, 'input or output path is inaccessible')
    for binary in (FFMPEG, FFPROBE):
        if not os.path.isfile(binary) or not os.access(binary, os.X_OK):
            raise CliError(3, 'required FFmpeg or ffprobe executable is missing')
    deadline = time.monotonic() + args.timeout
    temporary = None
    try:
        try:
            fd, name = tempfile.mkstemp(prefix='.audio-cli-', suffix='.wav', dir=target.parent)
            temporary = Path(name)
            os.close(fd)
        except OSError:
            raise CliError(2, 'output directory is not writable')
        status, _stdout, _tail = run_process([
            FFMPEG, '-nostdin', '-hide_banner', '-loglevel', 'error', '-y',
            '-protocol_whitelist', 'file', '-f', 'wav', '-i', str(source),
            '-map', '0:a:0', '-vn', '-ar', '16000', '-ac', '1',
            '-c:a', 'pcm_s16le', '-f', 'wav', str(temporary)], deadline)
        if status:
            raise CliError(4, 'audio conversion backend failed')
        metadata = verify_output(temporary, deadline)
        if time.monotonic() >= deadline:
            raise CliError(5, 'backend timed out')
        try:
            # Atomic create-if-absent: never replace an existing file/symlink.
            os.link(temporary, target)
        except FileExistsError:
            raise CliError(6, 'output already exists')
        except OSError:
            raise CliError(7, 'atomic output publication failed')
        return dict(output=str(target), **metadata)
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                print('warning: temporary artifact cleanup failed', file=sys.stderr)


def main(argv=None):
    parser = Parser(description='Convert a local PCM WAV to 16 kHz mono pcm_s16le WAV.', allow_abbrev=False)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--timeout', type=positive_timeout, default=30.0,
                        help='positive finite seconds for backend work (default: 30)')
    try:
        result = dict(ok=True, code=0, **convert(parser.parse_args(argv)))
    except CliError as exc:
        result = dict(ok=False, code=exc.code, error=str(exc))
        print(str(exc), file=sys.stderr)
    except (OSError, ValueError):
        result = dict(ok=False, code=2, error='invalid or inaccessible path')
        print(result['error'], file=sys.stderr)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return result['code']


if __name__ == '__main__':
    sys.exit(main())
