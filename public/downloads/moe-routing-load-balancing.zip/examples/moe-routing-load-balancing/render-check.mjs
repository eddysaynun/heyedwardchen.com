// Read-only use of the existing site's renderer; no site build/sync.
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const site=process.argv[2];
if (!site) throw new Error('usage: node render-check.mjs /absolute/site/path');
const {createMarkdownProcessor}=await import(pathToFileURL(path.join(site,'node_modules/@astrojs/markdown-remark/dist/index.js')));
const md=fs.readFileSync(path.join(here,'../../drafts/moe-routing-load-balancing.md'),'utf8');
const processor=await createMarkdownProcessor();
const result=await processor.render(md.replace(/^---\n[\s\S]*?\n---\n/,''));
const html=result.code;
if ((html.match(/<img /g)||[]).length!==4) throw new Error('missing figures');
if ((html.match(/<h2 /g)||[]).length!==8) throw new Error('expected seven sections plus references');
if (!html.includes('<ol>') || !html.includes('https://arxiv.org/html/2408.15664v1')) throw new Error('missing ordered references');
if (!html.includes('data-language="text"')) throw new Error('formula code blocks missing');
fs.writeFileSync(path.join(here,'article-rendered.html'),html);
console.log(JSON.stringify({images:4,h2:8,ordered_references:true,formula_code_blocks:true,site_modified:false}));
