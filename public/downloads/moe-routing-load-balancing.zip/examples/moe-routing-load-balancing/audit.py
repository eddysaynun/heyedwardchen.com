import json,hashlib,re,platform,datetime,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
article=root.parents[1]/'drafts/moe-routing-load-balancing.md'
s=article.read_text();body=s.split('## 参考资料')[0]
body=re.sub(r'^---\n.*?\n---\n','',body,flags=re.S)
prose=re.sub(r'```.*?```','',body,flags=re.S)
prose='\n'.join(x for x in prose.splitlines() if not x.startswith(('|','![','#')))
print('Chinese prose chars',len(re.findall('[\u4e00-\u9fff]',prose)))
print('Chinese all body chars',len(re.findall('[\u4e00-\u9fff]',body)))
print('body noncode chars',len(prose))
a=json.loads((root/'results/aggregate.json').read_text())
for method,v in [('none',0),('aux',1),('bias',.001),('bias',.1)]:
 r=[r for r in a['runs'] if not r['skew'] and r['method']==method and r['value']==v]
 cos=[];first=[];last=[]
 for x in r:
  rows=[json.loads(l) for l in (root/'results'/f"{x['run']}.steps.jsonl").read_text().splitlines()]
  cos += [t['gradient_cosine'] for t in rows if t['gradient_cosine'] is not None]
  first.append(rows[0]['aux_raw']);last.append(rows[-1]['aux_raw'])
 print(method,v,'negative cos',sum(x<0 for x in cos),'/',len(cos),'auxraw first last',sum(first)/3,sum(last)/3)
probe=(root/'markdown-render-probe.html').read_text();print('markdown probe',probe[:500])
