"""CPU teaching MoE; sigmoid scores, normalized selected weights, dense evaluation."""
import torch
from torch import nn


def route(scores, bias, k=2):
    # Only the discrete index is used. No gradient through top-k or bias.
    idx=(scores.detach()+bias.detach()).topk(k,dim=-1).indices
    selected=scores.gather(1,idx)
    weights=selected/selected.sum(-1,keepdim=True).clamp_min(1e-12)
    counts=torch.bincount(idx.flatten(),minlength=scores.shape[-1]).to(scores.dtype).detach()
    return idx,weights,counts


def balance_loss(scores,counts,k=2):
    # Paper Eq.2: f sums to N, not 1. Raw sigmoid P is NOT normalized.
    f=(counts*scores.shape[1]/(k*scores.shape[0])).detach()
    return (f*scores.mean(0)).sum(),f


@torch.no_grad()
def update_bias(bias,counts,speed):
    bias.add_(speed*torch.sign(counts.mean()-counts))


class MoE(nn.Module):
    def __init__(self):
        super().__init__()
        self.router=nn.Linear(8,4)
        self.experts=nn.ModuleList([nn.Sequential(nn.Linear(8,16),nn.Tanh(),nn.Linear(16,1)) for _ in range(4)])
        self.register_buffer('bias',torch.zeros(4))
        # A controlled initial preference, identical across ALL strategies.
        with torch.no_grad():
            self.router.weight.mul_(.3)
            self.router.bias.copy_(torch.tensor([1.,.4,-.4,-1.]))
    def forward(self,x):
        s=self.router(x).sigmoid()
        idx,w,c=route(s,self.bias)
        all_y=torch.cat([e(x) for e in self.experts],dim=1)
        y=(all_y.gather(1,idx)*w).sum(1)
        return y,s,idx,c
