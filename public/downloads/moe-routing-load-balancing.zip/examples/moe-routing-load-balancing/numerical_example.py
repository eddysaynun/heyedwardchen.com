import json
from pathlib import Path
import torch
from moe import route,balance_loss,update_bias

torch.set_printoptions(precision=8)
x=torch.tensor([[1.,-1.]],dtype=torch.double)
s_target=torch.tensor([[.7,.6,.4,.2]],dtype=torch.double)
W=torch.cat([torch.logit(s_target),torch.zeros(1,4,dtype=torch.double)],0)
z=x@W;s=z.sigmoid();b=torch.tensor([0.,0.,.31,0.],dtype=torch.double)
idx,w,c=route(s,b)
experts=torch.tensor([[[2.,0.],[0.,2.],[-1.,3.],[1.,-1.]]],dtype=torch.double)
selected=experts.gather(1,idx[:,:,None].expand(-1,-1,2))
y=(selected*w[:,:,None]).sum(1);raw,f=balance_loss(s,c)
q=z.detach().requires_grad_();ss=q.sigmoid();loss,ff=balance_loss(ss,c)
grad=torch.autograd.grad(loss,q)[0]
bn=b.clone();update_bias(bn,c,.01)
plain_i,plain_w,_=route(s,torch.zeros_like(b))
plain_selected=experts.gather(1,plain_i[:,:,None].expand(-1,-1,2))
plain_y=(plain_selected*plain_w[:,:,None]).sum(1)
r={'without_bias':{'indices_1based':(plain_i+1).tolist(),'weights':plain_w.tolist(),'output':plain_y.tolist()},
   'x':x.tolist(),'W':W.tolist(),'logits':z.tolist(),'scores':s.tolist(),'bias':b.tolist(),
   'selected_experts_1based':(idx+1).tolist(),'weights':w.tolist(),'expert_outputs':experts.tolist(),
   'weighted_output':y.tolist(),'with_residual':(x+y).tolist(),'counts':c.tolist(),'f':f.tolist(),
   'aux_raw':float(raw),'aux_gradient_logits':grad.tolist(),'bias_next':bn.tolist()}
Path('numerical-example.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
