import unittest
import torch
from moe import route, balance_loss, update_bias, MoE

class RoutingTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        torch.set_num_threads(1)
    def test_numerical_example(self):
        s=torch.tensor([[.7,.6,.4,.2]],dtype=torch.double,requires_grad=True)
        idx,w,c=route(s,torch.tensor([0.,0.,.3,0.]),2)
        self.assertEqual(set(idx[0].tolist()),{0,2})
        self.assertTrue(torch.allclose(w.sum(1),torch.ones(1,dtype=torch.double)))
        self.assertAlmostEqual(float(w[0,idx[0]==0]),.7/1.1)
        self.assertEqual(c.tolist(),[1.,0.,1.,0.])
    def test_bias_not_in_weights_or_graph(self):
        s=torch.tensor([[.8,.6,.2,.1]],requires_grad=True)
        b=torch.tensor([.01,.02,0.,0.],requires_grad=True)
        i,w,_=route(s,b,2); j,v,_=route(s,b*2,2)
        self.assertTrue(torch.equal(i,j)); self.assertTrue(torch.equal(w,v))
        (w*torch.tensor([[1.,3.]])).sum().backward()
        self.assertIsNone(b.grad); self.assertGreater(float(s.grad.abs().sum()),0)
    def test_aux_analytic_gradient_and_detach(self):
        z=torch.tensor([[1.,.5,-.5,-1.],[.8,.4,-.3,-.8]],dtype=torch.double,requires_grad=True)
        s=z.sigmoid(); _,_,c=route(s,torch.zeros(4),2)
        loss,f=balance_loss(s,c,2)
        self.assertFalse(f.requires_grad); self.assertFalse(c.requires_grad)
        grad=torch.autograd.grad(loss,z)[0]
        expected=f[None,:]*s.detach()*(1-s.detach())/2
        torch.testing.assert_close(grad,expected)
        # Fixed support away from ties: smooth sigmoid branch only.
        torch.autograd.gradcheck(lambda a:(a.sigmoid().mean(0)*f).sum(),(z,))
    def test_aux_has_no_expert_gradient(self):
        m=MoE(); _,s,_,c=m(torch.randn(16,8)); loss,_=balance_loss(s,c,2)
        loss.backward()
        self.assertTrue(all(p.grad is None for p in m.experts.parameters()))
        self.assertGreater(float(m.router.weight.grad.abs().sum()),0)
    def test_task_selected_expert_gradient(self):
        m=MoE(); m.bias.copy_(torch.tensor([10.,10.,-10.,-10.]))
        out,*_=m(torch.randn(16,8)); out.square().mean().backward()
        self.assertGreater(float(m.router.weight.grad.abs().sum()),0)
        for i,e in enumerate(m.experts):
            norm=sum(float(p.grad.abs().sum()) for p in e.parameters())
            self.assertGreater(norm,0) if i<2 else self.assertEqual(norm,0)
    def test_bias_update_timing_and_sign(self):
        m=MoE(); x=torch.randn(32,8); _,_,idx,c=m(x)
        before=m.bias.clone(); frozen_idx=idx.clone()
        update_bias(m.bias,c,.1)
        torch.testing.assert_close(m.bias,before+.1*torch.sign(c.mean()-c))
        self.assertTrue(torch.equal(idx,frozen_idx))
        self.assertFalse(m.bias.requires_grad)
        self.assertNotIn('bias',dict(m.named_parameters()))
    def test_zero_controls_equivalent(self):
        m=MoE(); x=torch.randn(16,8); a=m(x)[0]
        update_bias(m.bias,m(x)[3],0.)
        torch.testing.assert_close(a,m(x)[0],rtol=0,atol=0)
    def test_task_gradcheck_fixed_support(self):
        z=torch.tensor([[1.4,.7,-.6,-1.3]],dtype=torch.double,requires_grad=True)
        outputs=torch.tensor([[2.,-1.,3.,4.]],dtype=torch.double)
        def fun(a):
            i,w,_=route(a.sigmoid(),torch.zeros(4),2)
            return (outputs.gather(1,i)*w).sum()
        self.assertGreater(float(z[0,1]-z[0,2]),1.)
        self.assertTrue(torch.autograd.gradcheck(fun,(z,),eps=1e-6))
    def test_zero_controls_training_step(self):
        import copy
        base=MoE(); models=[copy.deepcopy(base) for _ in range(3)]
        x=torch.randn(16,8); y=torch.randn(16)
        for j,m in enumerate(models):
            opt=torch.optim.Adam(m.parameters(),lr=.003)
            pred,s,_,c=m(x); aux,_=balance_loss(s,c)
            loss=(pred-y).square().mean()+(0.*aux if j==1 else 0.)
            opt.zero_grad();loss.backward();opt.step()
            if j==2:update_bias(m.bias,c,0.)
        for m in models[1:]:
            for k,v in m.state_dict().items():
                torch.testing.assert_close(v,models[0].state_dict()[k],rtol=0,atol=0)
    def test_counts_and_batch_independence(self):
        s=torch.rand(19,4); b=torch.rand(4)
        i,w,c=route(s,b,2)
        self.assertEqual(float(c.sum()),38.)
        j,v,_=route(s[:1],b,2)
        self.assertTrue(torch.equal(i[:1],j)); torch.testing.assert_close(w[:1],v)

if __name__=='__main__': unittest.main(verbosity=2)
