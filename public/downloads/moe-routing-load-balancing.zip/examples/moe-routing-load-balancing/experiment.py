"""Reproducible synthetic regression, no test-driven hyperparameter selection."""
import argparse, hashlib, json, platform, time
from pathlib import Path
import numpy as np
import torch
from moe import MoE,balance_loss,update_bias

GRID=[('none',0.),('aux',.01),('aux',.1),('aux',1.),('bias',.001),('bias',.01),('bias',.1)]

def tensor_hash(items):
    h=hashlib.sha256()
    for k,v in sorted(items.items()):
        h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def data(seed,skew):
    g=torch.Generator().manual_seed(10000+seed)
    probs=torch.tensor([.7,.1,.1,.1] if skew else [.25]*4)
    result={}
    # Four latent input regimes, NOT expert labels. A shared plus contextual target.
    for name,n in [('train',4096),('val',1024),('test',1024)]:
        z=torch.multinomial(probs,n,replacement=True,generator=g)
        x=torch.randn(n,8,generator=g)
        centers=torch.tensor([[-1.,-1.],[-1.,1.],[1.,-1.],[1.,1.]])
        x[:,:2]=centers[z]+.35*x[:,:2]
        contextual=torch.stack([torch.sin(2*x[:,2])+x[:,3]*x[:,4],
            torch.cos(2*x[:,3])+.5*x[:,2].square(),
            torch.tanh(x[:,4]*2)-x[:,2]*x[:,3],
            torch.sin(x[:,2]+x[:,4])+x[:,3]],1)
        y=.5*x[:,5]+contextual.gather(1,z[:,None]).squeeze(1)+.05*torch.randn(n,generator=g)
        result[name]={'x':x,'y':y,'z':z}
    return result

def metrics(m,d,previous=None):
    with torch.no_grad():
        y,s,idx,c=m(d['x']); f=c/(len(y)*2)
        mask=torch.zeros(len(y),4,dtype=torch.bool).scatter_(1,idx,True)
        change=None if previous is None else float((mask!=previous).any(1).float().mean())
        return {'mse':float((y-d['y']).square().mean()),'loads':f.tolist(),
            'maxvio':float(c.max()/c.mean()-1),'route_change':change,
            'mean_scores':s.mean(0).tolist()},mask

def run(out,seed,skew,method,value,steps):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    torch.manual_seed(seed);m=MoE();initial=tensor_hash(m.state_dict())
    ds=data(seed,skew);dname=f'data-{seed}-{skew}.pt'
    if not (out/dname).exists():torch.save(ds,out/dname)
    hashes={n:tensor_hash(d) for n,d in ds.items()}
    name=f'{skew}-{method}-{value:g}-seed{seed}'
    config={'seed':seed,'skew':skew,'method':method,'value':value,'steps':steps,
        'batch_size':128,'learning_rate':.003,'optimizer':'Adam','device':'cpu','threads':1,
        'initial_weight_sha256':initial,'dataset_hashes':hashes,'data_file':dname,
        'torch':torch.__version__,'numpy':np.__version__,'platform':platform.platform(),
        'score':'sigmoid','selected_weights':'renormalized','capacity':None,'drop':False}
    (out/f'{name}.config.json').write_text(json.dumps(config,indent=2))
    torch.save(m.state_dict(),out/f'{name}.initial.pt')
    opt=torch.optim.Adam(m.parameters(),lr=.003)
    g=torch.Generator().manual_seed(20000+seed)
    val,old=metrics(m,ds['val']);history=[dict(step=0,**val)]
    start=time.perf_counter()
    with (out/f'{name}.steps.jsonl').open('w') as log:
        for step in range(1,steps+1):
            rows=torch.randint(4096,(128,),generator=g);x=ds['train']['x'][rows];y=ds['train']['y'][rows]
            before=m.bias.clone();pred,s,idx,c=m(x)
            main=(pred-y).square().mean();aux,f=balance_loss(s,c)
            alpha=value if method=='aux' else 0.
            cosine=None;gnorm=None
            if step==1 or step%50==0:
                params=list(m.router.parameters())
                gm=torch.cat([v.flatten() for v in torch.autograd.grad(main,params,retain_graph=True)])
                ga=torch.cat([v.flatten() for v in torch.autograd.grad(aux,params,retain_graph=True)])
                cosine=float(torch.dot(gm,ga)/(gm.norm()*ga.norm()+1e-12))
                gnorm=[float(gm.norm()),float(ga.norm()),float(alpha*ga.norm())]
            opt.zero_grad();(main+alpha*aux).backward();opt.step()
            if method=='bias':update_bias(m.bias,c,value)
            row={'step':step,'task_mse':float(main.detach()),'aux_raw':float(aux.detach()),
                 'aux_weighted':float(alpha*aux.detach()),'loads':(c/256).tolist(),
                 'maxvio':float(c.max()/c.mean()-1),'bias_before':before.tolist(),
                 'bias_after':m.bias.tolist(),'gradient_cosine':cosine,'router_grad_norms':gnorm}
            log.write(json.dumps(row)+'\n')
            if step%50==0 or step==steps:
                val,old=metrics(m,ds['val'],old);history.append(dict(step=step,**val))
    elapsed=time.perf_counter()-start
    # Final test is only read after training; all grid settings reported, none selected.
    test,_=metrics(m,ds['test'])
    summary=dict(config,run=name,seconds=elapsed,validation=history[-1],test=test,
                 parameters=sum(p.numel() for p in m.parameters()))
    (out/f'{name}.validation.json').write_text(json.dumps(history,indent=2))
    (out/f'{name}.summary.json').write_text(json.dumps(summary,indent=2))
    torch.save(m.state_dict(),out/f'{name}.final.pt')
    print(name,round(elapsed,3),'test_mse',round(test['mse'],4),'maxvio',round(test['maxvio'],4),flush=True)
    return summary

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='results');p.add_argument('--steps',type=int,default=600)
    p.add_argument('--seeds',nargs='+',type=int,default=[11,22,33]);p.add_argument('--distributions',nargs='+',choices=['uniform','skew'],default=['uniform','skew'])
    p.add_argument('--pilot',action='store_true');a=p.parse_args();torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    start=time.perf_counter();results=[]
    for skew in a.distributions:
        for seed in a.seeds:
            for method,value in (GRID[:1] if a.pilot else GRID):
                results.append(run(a.out,seed,skew=='skew',method,value,a.steps))
    Path(a.out,'aggregate.json').write_text(json.dumps({'runs':results,'wall_seconds':time.perf_counter()-start},indent=2))
if __name__=='__main__':main()
