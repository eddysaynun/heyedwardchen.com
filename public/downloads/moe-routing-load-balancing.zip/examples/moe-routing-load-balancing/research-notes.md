# 原始论文细读与来源核查

## 固定版本与实际读取

- 来源登记 [1]：https://arxiv.org/html/2408.15664v1 。HTML 正文标明 arXiv:2408.15664v1，2024-08-28；没有将它称为最新版本。
- 本轮通过 curl 从 arxiv.org 实际下载全文，保存 `paper-v1.html`，将 MathML 的 alttext 替换成原始公式后转为 `paper-v1.txt`（36630 字符）。原始工作目录保存全文；交付 ZIP 不再分发该全文。
- 阅读输出覆盖文本 0–12000、11700–14500、12630–36630，合并无空洞，涵盖摘要、§1–6、参考文献与附录 A–D。不是从旧 handoff 摘要重写。
- 研究时额外打开了算法 1 所在 11700–14500 区间，核对偏置更新在训练 batch 之后。
- 来源 ledger 为本任务独立 `sources.json`。其中附有从实际全文验证的短原句，确认 bias 不加入输出权重。

## 公式与算法

- Eq.1：h=u+sum(g_i FFN_i(u))；g_i 是被选中的原始评分 s_i，没有本文的选中归一化。
- Eq.2：L_balance=alpha*sum(f_i P_i)；f_i=N/(K*T)*count_i，P_i=mean(s_i)。f_i 均匀时为 1，和为 N，并非通常和为 1 的份额。正文将 T（原文序列长度）改作合成 batch 内样本数。
- Eq.3：比较 s_i+b_i 确定选中集合，输出系数仍是 s_i。不能把 s+b 直接用于输出混合。
- Algorithm 1：初始化 b=0；用既有 b 训练当前 batch；统计已经发生的分配；e=mean(c)-c；b+=u*sign(e)；下一 batch 使用新值。没有 EMA、偏置可学习梯度、当前 batch 迭代重排。
- Eq.4：MaxVio=(max_load-mean_load)/mean_load。论文区分 global/batch，实验也分开记录训练 batch 和整个验证集。
- 本文解析导数与归一化门控导数为对上述教学实现的自行推导，并用测试验证，不伪装成论文的新公式。

## 实验与消融核查

- §4.1：主要实验使用 sigmoid；附录 C 单独讨论 softmax。主实验骨干是 DeepSeekMoE，包含共享专家与细粒度专家，而教学例没有这些模块。
- Table 2：论文作者报告 1B 的 loss-controlled/loss-free 验证困惑度 9.56/9.50，global MaxVio 0.72/0.04；3B 为 7.97/7.92 和 0.52/0.04。文章没有把这些数字当作本地复现实验。
- §4.3 / Figure 4：比较更新率 0.0001、0.001、0.01；低速度初期恢复慢，高速度后期波动，论文采用 0.001。这不是本例速度的最优性保证。
- Table 3：sign 更新的 PPL 9.50、MaxVio 0.044；误差幅度更新的三组 PPL 9.53/9.51/9.51，MaxVio 0.028/0.036/0.040。均衡更好不必然对应困惑度更好。
- Table 4：乘法 bias 初始化为 1；与加法相比无明显均衡收益且 PPL 略差。本文只实现加法 sign 规则。
- §5.1：computation batch 与 expert parallelism 讨论；本文没有相应多设备实验。
- §5.2、附录 D：讨论 Expert Choice 的未来 token 信息泄漏与 chunk/shuffle 实验；本文未实现 Expert Choice，不用合成回归验证因果掩码。
- 附录 A：论文 1B/3B 都有 64 个 routed experts、6 个 activated routed experts、2 个 shared experts；本文 N=4,K=2，无 shared。
- 附录 B：1B 为 100B token、3B 为 200B；v1 的结论段写 300B，与摘要、§4.1、附录 B 不一致。正文不引用这个有内部冲突的结论数字。
- 附录 C：softmax baseline 与 sigmoid 不同，且 loss-free softmax 使用按误差幅度更新的变体。因此不能把本例 sigmoid+sign 的结果概括成所有评分函数的结论。

## 本实现和论文的差异

核心差异：选中分数重归一化；合成回归而非自回归语言模型；四个 tiny experts；无残差/共享专家；人为不对称 router 初始化；按独立样本 batch 而非序列衡量负载；dense experts 后 gather 而非 sparse dispatch；无容量/drop/通信/吞吐研究。动态 bias 的选择/加权分离和历史更新顺序保留。

## 站点 Markdown 能力（只读检查）

实际读取 `/Users/edward/workspace/edward/heyedwardchen.com/astro.config.mjs`、`package.json`、`src/content/config.ts`。配置只有图片属性 rehype 插件，未启用数学插件。现有 `@astrojs/markdown-remark` 渲染探针确认 `$x^2$` 保留为普通文本，代码块与 Markdown 图片正常渲染。

正文使用 text 代码块公式及 PNG 图；frontmatter 采用现有 schema 支持的 title/description/tags/draft/pinned，不虚构 pubDate。未运行站点 build/sync、未修改网站或 Obsidian。

## 图像检查

四张图均通过 vision_analyze 实际读取。初版负载图图例遮挡末柱，已移至右侧外部；初版主任务轴截断起始值，已改自动上界；初版计算图错误连接 weighted sum→counts，已重构成明确的 indices→bincount 分支。三张修改后的图片再经 vision_analyze 检查通过；tradeoff 初版可读，误差棒交叠反映种子波动，正文说明标准差含义。
