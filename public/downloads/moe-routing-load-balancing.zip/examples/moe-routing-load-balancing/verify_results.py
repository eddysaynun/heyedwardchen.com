"""Read back every original run and recompute final metrics from saved weights."""
import json,time,hashlib
from pathlib import Path
import torch
from moe import MoE
from experiment import tensor_hash,metrics,GRID

def main():
    root=Path(__file__).resolve().parent;start=time.perf_counter();torch.set_num_threads(1)
    a=json.loads((root/'results/aggregate.json').read_text());runs=a['runs']
    assert len(runs)==42
    counts=0;hashes={};datasets={};max_error=0.
    for r in runs:
        cfg=json.loads((root/'results'/f"{r['run']}.config.json").read_text())
        assert cfg['steps']==1200
        init=torch.load(root/'results'/f"{r['run']}.initial.pt",weights_only=True)
        assert tensor_hash(init)==cfg['initial_weight_sha256']
        hashes.setdefault(r['seed'],set()).add(cfg['initial_weight_sha256'])
        ds=torch.load(root/'results'/cfg['data_file'],weights_only=True)
        for n in ds:assert tensor_hash(ds[n])==cfg['dataset_hashes'][n]
        datasets.setdefault((r['seed'],r['skew']),set()).add(json.dumps(cfg['dataset_hashes'],sort_keys=True))
        logs=[json.loads(x) for x in (root/'results'/f"{r['run']}.steps.jsonl").read_text().splitlines()]
        assert len(logs)==1200
        previous=torch.zeros(4)
        for i,row in enumerate(logs,1):
            assert row['step']==i
            before=torch.tensor(row['bias_before']);after=torch.tensor(row['bias_after'])
            torch.testing.assert_close(before,previous,rtol=0,atol=0)
            loads=torch.tensor(row['loads']);assert abs(float(loads.sum())-1)<1e-7
            expected=before+(r['value']*torch.sign(.25-loads) if r['method']=='bias' else 0)
            torch.testing.assert_close(after,expected,rtol=0,atol=2e-7)
            assert abs(row['aux_weighted']-row['aux_raw']*(r['value'] if r['method']=='aux' else 0))<1e-6
            previous=after
        counts+=len(logs)
        history=json.loads((root/'results'/f"{r['run']}.validation.json").read_text())
        assert len(history)==25 and history[0]['step']==0 and history[-1]['step']==1200
        m=MoE();m.load_state_dict(torch.load(root/'results'/f"{r['run']}.final.pt",weights_only=True))
        actual,_=metrics(m,ds['test'])
        err=abs(actual['mse']-r['test']['mse']);max_error=max(err,max_error)
        assert err<1e-7
        assert actual['loads']==r['test']['loads'] and actual['maxvio']==r['test']['maxvio']
    assert all(len(x)==1 for x in hashes.values())
    assert all(len(x)==1 for x in datasets.values())
    assert len(set((r['skew'],r['seed'],r['method'],r['value']) for r in runs))==42
    out={'verified_runs':len(runs),'verified_training_step_records':counts,
         'recomputed_test_checkpoints':len(runs),'max_test_mse_difference':max_error,
         'matched_initial_hashes_per_seed':{str(k):list(v)[0] for k,v in hashes.items()},
         'matched_dataset_conditions':len(datasets),'seconds':time.perf_counter()-start}
    (root/'results-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
