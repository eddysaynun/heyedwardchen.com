import json, csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from experiment import GRID

ROOT=Path(__file__).resolve().parent
runs=json.loads((ROOT/'results/aggregate.json').read_text())['runs']
figdir=ROOT/'figures';figdir.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
colors=plt.cm.tab10(np.arange(7))
summary=[]
for skew in [False,True]:
    for method,value in GRID:
        group=[r for r in runs if r['skew']==skew and r['method']==method and r['value']==value]
        row={'distribution':'skew' if skew else 'uniform','method':method,'value':value}
        for key in ['mse','maxvio']:
            a=np.array([r['test'][key] for r in group]);row[key+'_mean']=float(a.mean());row[key+'_sd']=float(a.std(ddof=1))
        row['route_change_mean']=float(np.mean([r['validation']['route_change'] for r in group]))
        row['test_loads_mean']=np.mean([r['test']['loads'] for r in group],axis=0).tolist()
        row['mean_score']=float(np.mean([r['validation']['mean_scores'] for r in group]))
        summary.append(row)
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2))
with (ROOT/'summary.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=summary[0].keys());w.writeheader();w.writerows(summary)
# Exact validation evaluations: mean +/- sample standard deviation, no smoothing.
fig,axes=plt.subplots(2,2,figsize=(13,8),layout='constrained')
for col,skew in enumerate([False,True]):
    for j,(method,value) in enumerate(GRID):
        group=[r for r in runs if r['skew']==skew and r['method']==method and r['value']==value]
        histories=[json.loads((ROOT/'results'/f"{r['run']}.validation.json").read_text()) for r in group]
        x=[h['step'] for h in histories[0]]
        for row,key in enumerate(['mse','maxvio']):
            y=np.array([[h[key] for h in hs] for hs in histories]);avg=y.mean(0);sd=y.std(0,ddof=1)
            axes[row,col].plot(x,avg,color=colors[j],label=f'{method} {value:g}')
            axes[row,col].fill_between(x,np.maximum(avg-sd,0),avg+sd,color=colors[j],alpha=.08)
            axes[row,col].set_xlabel('Training step');axes[row,col].set_ylabel('Validation '+key)
    axes[0,col].set_title('Skewed inputs 70/10/10/10' if skew else 'Uniform inputs 25/25/25/25')
    axes[0,col].set_ylim(bottom=0);axes[1,col].set_ylim(0,1.05)
fig.suptitle('Validation trajectories: mean +/- sample SD over 3 seeds',fontsize=13)
axes[0,0].legend(ncol=2,fontsize=9);fig.savefig(figdir/'curves.png',dpi=160);plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
for ax,skew in zip(axes,[False,True]):
    group=[r for r in summary if r['distribution']==('skew' if skew else 'uniform')]
    for j,r in enumerate(group):
        ax.errorbar(r['maxvio_mean'],r['mse_mean'],xerr=r['maxvio_sd'],yerr=r['mse_sd'],fmt='o',color=colors[j],capsize=3,label=f"{r['method']} {r['value']:g}")
    ax.set_xlabel('Test MaxVio (lower = more balanced)');ax.set_ylabel('Test MSE (lower = better)')
    ax.set_title('Skewed inputs' if skew else 'Uniform inputs');ax.grid(alpha=.2)
axes[1].legend(fontsize=9);fig.savefig(figdir/'tradeoff.png',dpi=160);plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
for ax,skew in zip(axes,[False,True]):
    group=[r for r in summary if r['distribution']==('skew' if skew else 'uniform')]
    bottom=np.zeros(7)
    for e in range(4):
        values=np.array([r['test_loads_mean'][e] for r in group]);ax.bar(np.arange(7),values,bottom=bottom,label=f'Expert {e+1}');bottom+=values
    ax.set_xticks(np.arange(7),[f"{r['method']}\n{r['value']:g}" for r in group]);ax.set_ylim(0,1)
    ax.set_ylabel('Fraction of top-2 assignments');ax.set_title('Skewed inputs' if skew else 'Uniform inputs')
axes[1].legend(loc='center left',bbox_to_anchor=(1.01,.5),fontsize=9);fig.savefig(figdir/'loads.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(13,6),layout='constrained');ax.axis('off')
texts=[('1  SCORES AND DISCRETE SELECTION',
        'X [T,d] -> router -> sigmoid -> S [T,N]\nI [T,K] = topk_indices(stopgrad(S) + b[N])', '#e9f0ff'),
       ('2  DIFFERENTIABLE OUTPUT PATH (given I)',
        'w [T,K] = normalize(gather(S, I))    # original scores, NOT S+b\nE [T,K,d] = gather(experts(X), I)\nY [T,d] = sum_k(w * E) -> task loss', '#e6f4e8'),
       ('3  LOAD FEEDBACK: NO GRADIENT; NEXT BATCH ONLY',
        'I -> bincount -> c [N]     # counts come from indices, NOT Y\nb_next = b + speed * sign(mean(c) - c)\nFinish this batch; use b_next in step 1 of the NEXT batch.', '#fff0dc')]
for y,(title,text,color) in zip([.83,.5,.16],texts):
    ax.text(.02,y+.1,title,transform=ax.transAxes,fontsize=12,fontweight='bold')
    ax.text(.02,y,text,transform=ax.transAxes,fontsize=12,fontfamily='monospace',va='top',
            bbox=dict(boxstyle='round,pad=.7',facecolor=color,edgecolor='#526580'))
ax.set_title('Separate expert selection, output weights, and load feedback',fontsize=16,pad=20)
fig.savefig(figdir/'routing.png',dpi=160);plt.close(fig)
print(json.dumps(summary,indent=2));print('figures',len(list(figdir.glob('*.png'))))
