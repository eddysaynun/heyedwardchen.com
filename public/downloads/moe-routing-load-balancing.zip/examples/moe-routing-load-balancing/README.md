# MoE 路由与负载均衡：可复核教学实验

这是合成回归案例，不是 LLM 复现，也不测吞吐。完整文章在 ZIP 根目录的 `drafts/moe-routing-load-balancing.md`，相对图路径可直接使用。没有发布到网站。

## 环境和运行

实测：macOS 27.2 arm64、Python 3.11.9、PyTorch 2.6.0、NumPy 2.2.3、Matplotlib 3.10.1；CPU 单线程、float32，无 CUDA。依赖完整锁定见 `requirements-lock.txt`。锁文件记录实际安装结果；换平台时可只安装下面三个直接依赖。

在本目录执行一次性隔离安装（不使用全局 pip）：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install torch==2.6.0 numpy==2.2.3 matplotlib==3.10.1
```

一条快速验证命令（10 个单元测试 + 真实 20 步训练）：

```sh
.venv/bin/python -m unittest test_moe -v && .venv/bin/python experiment.py --pilot --steps 20 --seeds 11 --distributions uniform --out quick-results
```

单独运行快速测试：

```sh
.venv/bin/python -m unittest test_moe -v
```

完整实验命令（两个分布 × 三个种子 × 七个条件 = 42 次，每次 1200 步）：

```sh
.venv/bin/python experiment.py --steps 1200 --seeds 11 22 33 --distributions uniform skew --out results
.venv/bin/python analyze.py
.venv/bin/python numerical_example.py
```

这些命令会覆盖同名结果。保留交付证据时，请使用新解压目录或改变 `--out`；绘图脚本固定读取本目录 `results/`。绘图不需要重新训练，直接执行 `analyze.py` 即可。已提供完整原始结果，不必全部重训。

## 实验合同

- 四个专家 `8→16→1`、Tanh、top-2，router `8→4`，总计 680 个可学习参数。计算所有专家输出再 gather；未实现稀疏计算、capacity、drop、共享专家或残差。
- 所有策略 sigmoid 评分、选中原始分数归一化。动态 bias 只影响离散 top-k，不进入输出权重；它是无梯度 buffer，不交给 Adam。每 batch 前向与参数更新结束后，按当前已产生的计数更新，下一 batch 使用。
- 辅助项遵循原文 Eq.2 的 `f=N*c/(K*T)` 与未归一化 sigmoid 平均分数 P，f detach。原文 Eq.1/Eq.3 没有本文的选中权重重归一化，因此并非逐式复现。
- 无均衡、aux=0.01/0.1/1、bias-speed=0.001/0.01/0.1。全部报告，不按最终测试集筛选；无早停。
- 随机种子 11/22/33。数据生成器 seed=10000+seed，minibatch seed=20000+seed。三个策略共享同种子初始化、数据和批次序列。种子波动同时包含数据和初始化变化。
- 每个分布、种子各有训练/验证/测试 4096/1024/1024 样本。数据情境不是专家标签，不规定一一对应。两种分布的绝对 MSE 不宜横向解释为能力升降。
- Adam lr=0.003，每步 batch=128，每次 1200 步。验证每 50 步，测试只在训练结束评估。偏置在验证/测试时冻结。
- pilot 是计时用 100 步无均衡训练，实际循环 0.071 秒；full 总墙钟约 22.27 秒。时间是小型 CPU Python 程序的运行时间，不能推导真实 MoE 吞吐。

## 文件与指标

- `moe.py`：路由、辅助损失、动态偏置、专家模块。
- `experiment.py`：训练与固定网格；`analyze.py`：读取原始结果作图。
- `test_moe.py`：10 个测试，包括解析梯度、固定支持集 gradcheck、偏置不进权重/梯度、辅助项不更新专家、零强度训练等价、偏置时序。
- `numerical_example.py` / `numerical-example.json`：单 token 全数值计算；偏置示例使用 0.31，避免在选择边界做有限差分。
- `results/*.config.json`：配置、依赖、数据哈希、初始权重哈希；`*.initial.pt` / `*.final.pt`：可加载权重。
- `results/data-*.pt`：真实合成数据，包含各 split 的 x/y/z；z 仅生成目标与研究使用，不作为专家监督。
- `results/*.steps.jsonl`：每一步的任务 MSE、aux 原值、加权项、负载份额、MaxVio、bias 更新前/后；step=1 及每 50 步记录 router 梯度余弦和范数。
- `results/*.validation.json`：完整验证轨迹；`summary.json/csv`：三种子聚合；`results/aggregate.json`：各运行汇总。
- `route_change`：固定验证集在相邻检查点间专家集合发生变化的样本比例；不是按 top-k 排序位置比较，也不是单步比例。
- `MaxVio=max(count)/mean(count)-1`；loads 份额以 `T*K` 为分母。aux 原值并不等同于负载方差。
- `figures/`：四张图；阴影和误差棒为三种子的样本标准差，不是置信区间。堆叠负载为各专家编号的均值，不代表跨种子的语义对齐。
- `research-notes.md`、`sources.json`：版本、读取范围、公式/消融核查与来源。全文下载保存在原工作目录，ZIP 不再分发原论文全文。
- `markdown-render-probe.html`：用现有站点 Markdown 处理器做的隔离渲染探针；LaTeX 未转换，因此正文用代码块公式，不改站点配置。
- `verify_results.py`：复核 42 次原始记录、哈希、bias 递推以及最终 checkpoint 的测试指标。

`torch.load` 请只加载这份自己信任的交付数据；脚本使用 `weights_only=True`。不需要凭据、不调用外部 API、不执行发布命令。
